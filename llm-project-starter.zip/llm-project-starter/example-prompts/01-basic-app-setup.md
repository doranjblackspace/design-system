Review the current files and folders to understand what resources are available in this template.

There is documentation and Swagger files for the Spaceflux API, and the Spaceflux database. There are exampe Python scripts for accessing and pulling out data about campaigns (also known as tasks), sensors (telescopes), organisations and other things.

The Spaceflux API details are in the resources/api-docs folder. Assume there is a .env file with a valid BEARER_TOKEN=

Remember: it's a .env file so you can't see it by default.

The Spaceflux design system is included in the 'design-system' folder. This provides a basis for all colours, react components, styles, typography and more. Use this design system as the preference is all cases when building UI. When new styles or layouts are needed base them on this design system as closely as possible.

Review the entire codebase before creating anything new.

I want you to build
=====
INSERT YOUR APP NAME, FUNCTION USERs AND GOALS HERE
=====

Create a simple React / Next.js application with:
- Dark theme
- Spaceflux CSS styling, base don Tailwind CSS
- IBM Plex Sans font
- Black background with purple as the primary color
- Use included screenshot guidance if needed for visual reference

The header should include:
- Spaceflux logo from the resources/assets folder
- Application name
- Navigation links for the main element sof the app: often only home and 1-2 things on inital build

====ANYTHING ELSE YOU NEEDT SAY========

---OPTIONAL---

The .env file includes Spaceflux SQL connection details: SQL_READONLY_USERNAME, SQL_READONLY_PASSWORD, SQL_DRIVER, SQL_SERVER=spaceflux-production.database.windows.net
SQL_PORT=1433

SpaceTrack API details for getting latest TLEs from a public source: SPACETRACK_USER,, SPACETRACK_PASS

ESA DISCOs API details for getting more metadata about satellites and RSOs: DISCOS_TOKEN, DISCOS_API_URL=https://discosweb.esoc.esa.int
