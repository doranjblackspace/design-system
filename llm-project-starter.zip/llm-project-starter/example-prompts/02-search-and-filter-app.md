# Search and Filter Application Prompt

## Overview
This prompt guides you through building a search and filter interface for Spaceflux data.

## Prompt Template

```
Building on the basic app setup, create a search interface that:

1. **Search Page Features:**
   - Simple search form with queryable fields
   - Support for filtering by:
     - [Field 1] (e.g., NORAD IDs, satellite names, etc.)
     - [Field 2] (e.g., Date range, time period, etc.)
     - [Field 3] (e.g., Geographic parameters, orbital parameters, etc.)
   - Default values: [Specify defaults]
   - Allow multiple values where applicable (e.g., comma-separated IDs)

2. **Search Results:**
   - Query the Spaceflux API using endpoints from resources/api-docs
   - Display results in a table format
   - Exclude exclusive data from results
   - Provide filtering options on the results page
   - Allow users to select all or individual items
   - Include option to return to homepage

3. **API Integration:**
   - Use appropriate Spaceflux API endpoints from the catalog-service, campaign-service, or measurements-service
   - Handle authentication via BEARER_TOKEN from .env file
   - Implement proper error handling and loading states
```

## Usage Notes
- Replace `[Field 1]`, `[Field 2]`, `[Field 3]` with your specific search criteria
- Reference the appropriate OpenAPI spec files in resources/api-docs for endpoint details
- Customize the results display format based on your data structure
- Adjust filtering capabilities based on what the Spaceflux APIs support
