# Campaign Management Application Prompt

## Overview
This prompt guides you through building a campaign creation and management interface.

## Prompt Template

```
Create a campaign management interface for Spaceflux telescope observations:

1. **Campaign Creation:**
   - Form to create new observation campaigns
   - Required fields:
     - Campaign name
     - Target satellite (NORAD ID or TLE)
     - Orbital regime (LEO, MEO, GEO, etc.)
     - Start and end dates
     - Observation parameters (track length, min track separation, etc.)
   - Form validation with helpful error messages
   - Reference campaign-service.json API spec for required parameters

2. **Campaign List:**
   - Display all campaigns (active, completed, scheduled)
   - Filter by status, date range, satellite
   - Sort by creation date, start date, status
   - Show key information: name, target, status, dates

3. **Campaign Details:**
   - Detailed view for individual campaigns
   - Show campaign configuration
   - Display associated sessions and observations
   - Show measurement tracks if available
   - Status updates and timeline

4. **API Integration:**
   - Use campaign-service endpoints for CRUD operations
   - Use global-scheduler.json for scheduling information
   - Use measurements-service.json for observation data
   - Handle authentication and error responses appropriately
```

## Usage Notes
- Review campaign-service.json for all available campaign parameters
- Check global-scheduler.json for scheduling-related endpoints
- Consider implementing real-time status updates
- Handle different orbital regimes appropriately (LEO vs GEO parameters differ)
