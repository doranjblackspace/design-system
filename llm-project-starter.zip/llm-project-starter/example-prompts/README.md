# Example Prompts for Spaceflux Applications

This directory contains template prompts to guide you in building Spaceflux applications. Each prompt is designed to be generic and adaptable to your specific use case.

## Available Prompts

### 1. Basic App Setup (`01-basic-app-setup.md`)
Start here for a new application. Covers:
- Framework setup
- Styling and branding
- Header navigation
- API authentication setup

### 2. Search and Filter App (`02-search-and-filter-app.md`)
Build a search interface with filtering capabilities:
- Search forms
- API integration
- Results display
- Filtering options

### 3. Data Purchase and Download Flow (`03-data-purchase-flow.md`)
Implement a purchase workflow:
- Purchase initiation
- Purchase management
- Download options (ZIP, blob storage)

### 4. Dashboard and Visualization (`04-dashboard-and-visualization.md`)
Create dashboards with visualizations:
- Dashboard layout
- Charts and graphs
- Real-time updates
- User customization

### 5. Campaign Management (`05-campaign-management.md`)
Build campaign management interfaces:
- Campaign creation
- Campaign listing
- Campaign details
- Observation tracking

## How to Use These Prompts

1. **Choose a prompt** that matches your use case
2. **Customize the template** by replacing placeholder text (marked with `[brackets]`)
3. **Reference the API documentation** in `resources/api-docs/` for specific endpoints
4. **Use the assets** in `resources/assets/` for branding
5. **Check screenshots** in `resources/` for visual reference

## Available Resources

- **API Documentation**: OpenAPI specs in `resources/api-docs/`
  - `catalog-service.json` - Satellite catalog operations
  - `campaign-service.json` - Campaign management
  - `device-service.json` - Telescope/device information
  - `global-scheduler.json` - Scheduling operations
  - `measurements-service.json` - Observation measurements

- **Assets**: `resources/assets/`
  - `spaceflux-logo-dark.png` - Dark theme logo
  - `spaceflux-logo-light.png` - Light theme logo

- **Configuration**: `.env` file should contain `BEARER_TOKEN` for API authentication

## Tips

- Always review the OpenAPI specs to understand available endpoints and parameters
- Use the Spaceflux branding guidelines (dark theme, purple primary color, IBM Plex Sans font)
- Handle authentication via the BEARER_TOKEN from your `.env` file
- Consider error handling and loading states in all API integrations
- Reference the example screenshots for visual guidance

## Combining Prompts

These prompts can be combined to build more complex applications:
- Start with `01-basic-app-setup.md` for foundation
- Add `02-search-and-filter-app.md` for search functionality
- Include `03-data-purchase-flow.md` for e-commerce features
- Add `04-dashboard-and-visualization.md` for analytics
- Use `05-campaign-management.md` for observation management

## Contributing

When creating new prompts:
- Keep them generic and template-like
- Use `[placeholder]` format for customizable values
- Reference available resources
- Include usage notes
- Focus on guiding users, not prescribing exact implementations
