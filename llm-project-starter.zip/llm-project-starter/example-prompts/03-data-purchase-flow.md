# Data Purchase and Download Flow Prompt

## Overview
This prompt guides you through implementing a purchase and download workflow for Spaceflux data.

## Prompt Template

```
Building on the search and filter app, implement a data purchase and download workflow:

1. **Purchase Flow:**
   - After users select data from search results, allow them to initiate purchase
   - Initially implement a temporary "payment" dialog where:
     - User acknowledges this is free (but will be paid in the future)
     - User clicks confirm/OK
   - Later this will be replaced with an actual payment method (e.g., credit card input flow)

2. **Purchase Management:**
   - Create a "My Purchases" page showing:
     - List of bundles/packages of data the user has access to
     - Purchase date and expiration date
     - Status (active, expired, archived)
   - Purchases remain active for [X] days before being archived
   - During active period, users can return to download their data

3. **Download Options:**
   - Provide two download methods:
     - Method 1: Download as ZIP file
       - Handle batching if there are too many files
       - Show progress indicator
     - Method 2: Public blob storage
       - Place data into Azure blob storage (or other cloud storage)
       - Provide download link in UI
       - Send download link via email to user
   - Allow users to choose their preferred download method
```

## Usage Notes
- Replace `[X]` with your specific retention period (e.g., 30 days)
- Customize the purchase flow based on your business requirements
- Adjust download methods based on your infrastructure preferences
- Consider implementing email notifications using your preferred email service
