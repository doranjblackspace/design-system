# Dashboard and Visualization Prompt

## Overview
This prompt guides you through building a dashboard with data visualizations for Spaceflux data.

## Prompt Template

```
Create a dashboard page that visualizes Spaceflux data:

1. **Dashboard Layout:**
   - Responsive grid layout with multiple widget sections
   - Key metrics cards showing:
     - [Metric 1] (e.g., total satellites tracked, active campaigns, etc.)
     - [Metric 2] (e.g., observations today, telescope availability, etc.)
     - [Metric 3] (e.g., data volume, recent activity, etc.)
   - Interactive charts and graphs using [Chart library of choice]

2. **Visualization Components:**
   - Time series charts for [Your time-based data]
   - Geographic visualizations (maps) showing [Your geographic data]
   - Distribution charts for [Your categorical data]
   - Real-time updates if applicable

3. **Data Integration:**
   - Fetch data from Spaceflux APIs (campaign-service, measurements-service, device-service)
   - Cache data appropriately for performance
   - Implement refresh/polling mechanisms
   - Handle loading and error states gracefully

4. **User Customization:**
   - Allow users to customize dashboard widgets
   - Save user preferences (localStorage or backend)
   - Filter data by date range, satellite, telescope, etc.
```

## Usage Notes
- Replace `[Metric 1]`, `[Metric 2]`, `[Metric 3]` with your specific metrics
- Replace `[Chart library of choice]` with your preferred library (e.g., Chart.js, D3.js, Plotly)
- Replace `[Your time-based data]`, `[Your geographic data]`, etc. with your specific data types
- Reference the OpenAPI specs to understand available data endpoints
