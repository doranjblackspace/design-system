# Spaceflux LLM Project Starter

A template repository designed for AI-assisted development of Spaceflux applications. Clone this repo, customize the starter prompt, and let your AI coding assistant build a new application using the included resources.

> **Note**: This entire repository is intended to be replaced by your generated application. Clone fresh for each new project.

## Quick Start

1. **Clone this template**
   ```bash
   git clone <repository-url> my-new-spaceflux-app
   cd my-new-spaceflux-app
   rm -rf .git && git init
   ```

2. **Set up environment variables**
   ```bash
   cp env.example .env
   # Edit .env with your actual credentials (BEARER_TOKEN is required)
   ```

3. **Customize the starter prompt**
   
   Open `starter-prompt.txt` and fill in your application requirements in the marked section:
   ```
   I want you to build
   =====
   INSERT YOUR APP NAME, FUNCTION, USERS AND GOALS HERE
   =====
   ```

4. **Paste into your AI assistant**
   
   Copy the contents of `starter-prompt.txt` and paste it into Cursor, Claude, ChatGPT, or your preferred AI coding assistant to generate your application.

## What's Included

### `starter-prompt.txt`
The main entry point. A template prompt that instructs AI assistants to review the codebase and build a Spaceflux application using the included resources. Customize this with your specific requirements.

### `example-prompts/`
Additional prompt templates for common application patterns:
- `01-basic-app-setup.md` - Foundation with auth and branding
- `02-search-and-filter-app.md` - Search interfaces
- `03-data-purchase-flow.md` - Purchase workflows
- `04-dashboard-and-visualization.md` - Charts and analytics
- `05-campaign-management.md` - Campaign/task management

### `resources/`

| Folder | Contents |
|--------|----------|
| `api-docs/spaceflux-api/` | OpenAPI specs for Spaceflux services (campaigns, catalog, devices, scheduler, measurements) |
| `api-docs/esa-discos-api/` | ESA DISCOs API specification for satellite metadata |
| `design-system/` | Complete React/TypeScript component library, CSS tokens, page templates, and icons |
| `assets/` | Spaceflux logos (dark/light variants) |
| `example-scripts/` | Python scripts for API access, database queries, and deployment |
| `cortex-technical-documentation/` | Technical reference PDFs |

### `env.example`
Template for environment variables:
- `BEARER_TOKEN` - **Required** for Spaceflux API authentication
- `SPACETRACK_USER` / `SPACETRACK_PASS` - SpaceTrack API credentials
- `SQL_*` - Database connection settings
- `DISCOS_TOKEN` - ESA DISCOs API token

## Design Guidelines

When building Spaceflux applications, follow these conventions:

| Element | Value |
|---------|-------|
| Theme | Dark (default) |
| Primary Color | Purple (`#6B29AE`) |
| Accent Color | Medium Orchid (`#CF8BFF`) |
| Background | Dark surface (`#100919`) |
| Font | IBM Plex Sans (primary), NB Architekt Std (display) |
| Styling | Tailwind CSS |

See `resources/design-system/README.md` for complete design tokens and component documentation.

## How It Works

1. The AI assistant reads the entire codebase including API specs, design system, and example scripts
2. It uses these as context to generate your application with correct styling, API integration, and patterns
3. The generated code replaces this template entirely
4. You end up with a fully functional Spaceflux application

## Tips

- **Start simple**: Begin with basic requirements and iterate
- **Use example prompts**: Combine patterns from `example-prompts/` for complex features
- **Reference screenshots**: Include `resources/screenshot-spaceflux-website.png` for visual guidance
- **Check API specs**: The OpenAPI files define available endpoints and data structures
- **Leverage the design system**: Components in `resources/design-system/` provide production-ready patterns

---

*This is a template repository. After generating your application, this README should be replaced with documentation specific to your project.*
