export const RED_SQUARE_COLOR = '#F9130F';
export const GREEN_SQUARE_COLOR = '#20BF55';
export const BLUE_SQUARE_COLOR = '#004E98';
export const ORANGE_SQUARE_COLOR = '#FB7033';
export const YELLOW_SQUARE_COLOR = '#FFD711';
