export { default as SensorDetailsComponents } from './sensor-details';
