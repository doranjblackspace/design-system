const Filter = () => (
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M10.3333 17H13.6667V15.3333H10.3333V17ZM4.5 7V8.66667H19.5V7H4.5ZM7 12.8333H17V11.1667H7V12.8333Z"
      fill="#EEEEEE"
    />
  </svg>
);

export default Filter;
