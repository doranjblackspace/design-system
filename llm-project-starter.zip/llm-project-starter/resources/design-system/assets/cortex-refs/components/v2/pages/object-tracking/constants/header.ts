export const HEADER_OBJECT_TRACKING_TITLE = 'Object Tracking';
export const HEADER_OBJECT_TRACKING_DESCRIPTION =
  'Manage object data and network tasking.';

export const HEADER_NEW_OBJECT_TRACKING_TITLE = 'Custom Task';
export const HEADER_NEW_SUBSCRIPTION_TASK_TITLE = 'Monitoring Task';
export const HEADER_EDIT_OBJECT_TRACKING_TITLE = 'Edit Track';

export const HEADER_MANAGE_TASKS_TITLE = 'Task Manager';
export const HEADER_MANAGE_TASKS_DESCRIPTION =
  'View all the tasks via your packages. Manage and create new tasks.';
