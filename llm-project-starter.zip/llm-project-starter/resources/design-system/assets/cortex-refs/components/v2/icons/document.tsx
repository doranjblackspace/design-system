import React from "react";

function Document() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
    >
      <path
        d="M8 18H16V16H8V18ZM8 14H16V12H8V14ZM4 22V2H14L20 8V22H4ZM13 9V4H6V20H18V9H13Z"
        fill="#EEEEEE"
      />
    </svg>
  );
}

export default Document;
