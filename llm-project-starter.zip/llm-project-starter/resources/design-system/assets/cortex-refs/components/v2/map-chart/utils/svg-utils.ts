import { PIN_CONFIG } from '../constants/map-constants';

export const PIN_COLORS = PIN_CONFIG.COLORS;

const LOCATION_PIN_PATH =
  'M12 22.7279L5.636 16.3639C4.37734 15.1052 3.52019 13.5016 3.17293 11.7558C2.82567 10.0099 3.00391 8.20035 3.6851 6.55582C4.36629 4.91129 5.51984 3.50569 6.99988 2.51677C8.47992 1.52784 10.22 1 12 1C13.78 1 15.5201 1.52784 17.0001 2.51677C18.4802 3.50569 19.6337 4.91129 20.3149 6.55582C20.9961 8.20035 21.1743 10.0099 20.8271 11.7558C20.4798 13.5016 19.6227 15.1052 18.364 16.3639L12 22.7279ZM16.95 14.9499C17.9289 13.9709 18.5955 12.7236 18.8656 11.3658C19.1356 10.0079 18.9969 8.60052 18.4671 7.32148C17.9373 6.04244 17.04 4.94923 15.8889 4.18009C14.7378 3.41095 13.3844 3.00043 12 3.00043C10.6156 3.00043 9.26222 3.41095 8.11109 4.18009C6.95996 4.94923 6.06275 6.04244 5.53292 7.32148C5.00308 8.60052 4.86442 10.0079 5.13445 11.3658C5.40449 12.7236 6.07111 13.9709 7.05 14.9499L12 19.8999L16.95 14.9499ZM12 11.9999C11.4696 11.9999 10.9609 11.7892 10.5858 11.4141C10.2107 11.0391 10 10.5304 10 9.99992C10 9.46949 10.2107 8.96078 10.5858 8.58571C10.9609 8.21064 11.4696 7.99992 12 7.99992C12.5304 7.99992 13.0391 8.21064 13.4142 8.58571C13.7893 8.96078 14 9.46949 14 9.99992C14 10.5304 13.7893 11.0391 13.4142 11.4141C13.0391 11.7892 12.5304 11.9999 12 11.9999Z';

export const createLocationPinSVG = (
  color: string = PIN_COLORS.DEFAULT,
  size: number = PIN_CONFIG.SIZE
): string => {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="${LOCATION_PIN_PATH}" fill="${color}"/>
  </svg>`;
};

export const svgToDataURL = (svgString: string): string => {
  const encodedSvg = encodeURIComponent(svgString);
  return `data:image/svg+xml,${encodedSvg}`;
};

export const createLocationPinDataURL = (
  isSelected: boolean = false,
  size: number = PIN_CONFIG.SIZE
): string => {
  const color = isSelected ? PIN_COLORS.SELECTED : PIN_COLORS.DEFAULT;
  const svgString = createLocationPinSVG(color, size);
  return svgToDataURL(svgString);
};

export const LOCATION_PIN_DATA_URLS = {
  DEFAULT: createLocationPinDataURL(false),
  SELECTED: createLocationPinDataURL(true),
} as const;

export const getLocationPinDataURL = (props: {
  isSelected: boolean;
  isObserving: boolean;
}): string => {
  let color: string = PIN_COLORS.DEFAULT;

  if (props.isObserving && !props.isSelected) {
    color = PIN_COLORS.OBSERVING;
  }

  if (props.isSelected) {
    color = PIN_COLORS.SELECTED;
  }

  const svgString = createLocationPinSVG(color);
  return svgToDataURL(svgString);
};
