export const HEADER_SENSOR_TITLE = 'Sensor Network';
export const HEADER_SENSOR_DESCRIPTION =
  'Monitor our sensor network in real-time, access sensor details.';
// TODO: add back when feature is available
// export const HEADER_SENSOR_DESCRIPTION =
//   'Monitor our sensor network in real-time, access sensor details, and retrieve calibration data.';
