export const HEADER_LAUNCHPAD_TITLE = 'Welcome';
export const HEADER_LAUNCHPAD_DESCRIPTION = 'Recent data and network status.';
