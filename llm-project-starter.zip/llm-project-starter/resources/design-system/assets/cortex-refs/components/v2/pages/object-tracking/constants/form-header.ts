export const CUSTOM_TASK_FORM_TITLE = 'Track An Object';
export const SUBSCRIPTION_TASK_FORM_TITLE = 'Add To List';

export const FORM_PREVIEW_CONFIG = {
  title: 'Verify & Confirm',
  description:
    'Please review the data below and consider what is best for your needs.',
} as const;
