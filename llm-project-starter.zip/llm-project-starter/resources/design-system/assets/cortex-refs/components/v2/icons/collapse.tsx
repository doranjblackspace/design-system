const CollapseIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M3.0625 18L2 16.9375L7.4375 11.5H4V10H10V16H8.5V12.5625L3.0625 18ZM10 10V4H11.5V7.4375L16.9375 2L18 3.0625L12.5625 8.5H16V10H10Z"
      fill="#382C47"
    />
  </svg>
);

export default CollapseIcon;
