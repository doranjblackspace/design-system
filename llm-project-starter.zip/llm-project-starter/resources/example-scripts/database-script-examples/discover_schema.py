#!/usr/bin/env python3
"""
Spaceflux Cortex Database Schema Discovery Tool

This script discovers and documents all accessible databases, tables, and columns
in the Spaceflux Cortex database system.

Requirements:
    pip install sqlalchemy pyodbc python-dotenv

Environment Variables (in .env file):
    SQL_SERVER=your-server.database.windows.net
    SQL_PORT=1433
    SQL_READONLY_USERNAME=your_username
    SQL_READONLY_PASSWORD=your_password
    SQL_DRIVER=FreeTDS  # or "ODBC Driver 17 for SQL Server"

Usage:
    python discover_schema.py              # Output to console
    python discover_schema.py --json       # Output as JSON
    python discover_schema.py --markdown   # Output as Markdown
"""

import os
import sys
import json
import urllib.parse
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from sqlalchemy import create_engine, text, Engine, inspect
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Known Spaceflux Cortex databases
DATABASES = {
    "device": "Device/Hardware management - telescopes, observatories, sensors",
    "identity": "Account/Identity management - users, organizations, roles",
    "measurement": "Measurements/Observations - tracking data, measurements",
    "catalog": "Space Object Catalog - orbital elements, TLE data",
    "campaign": "Campaign management - missions, network assignments",
}


def build_engine(db_name: str) -> Engine:
    """Build database engine using environment variables."""
    driver = os.getenv("SQL_DRIVER", "ODBC Driver 17 for SQL Server")
    server = os.getenv("SQL_SERVER")
    port = os.getenv("SQL_PORT", "1433")
    user = os.getenv("SQL_READONLY_USERNAME")
    password = os.getenv("SQL_READONLY_PASSWORD")

    missing = [k for k, v in [
        ("SQL_SERVER", server),
        ("SQL_READONLY_USERNAME", user),
        ("SQL_READONLY_PASSWORD", password),
    ] if not v]
    if missing:
        raise EnvironmentError(f"Missing required environment variables: {', '.join(missing)}")

    driver_enc = urllib.parse.quote_plus(driver)
    user_enc = urllib.parse.quote_plus(user)
    pwd_enc = urllib.parse.quote_plus(password)

    if driver == "FreeTDS":
        uri = f"mssql+pyodbc://{user_enc}:{pwd_enc}@{server}:{port}/{db_name}?driver={driver_enc}&TDS_Version=8.0&Encrypt=yes&TrustServerCertificate=yes"
    else:
        uri = f"mssql+pyodbc://{user_enc}:{pwd_enc}@{server}:{port}/{db_name}?driver={driver_enc}"
    
    return create_engine(uri, pool_size=5, max_overflow=10, future=True)


def test_connection(db_name: str) -> bool:
    """Test if we can connect to a database."""
    try:
        engine = build_engine(db_name)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            return True
    except Exception:
        return False


def get_row_count_estimate(engine: Engine, table_name: str) -> int:
    """Get estimated row count from system tables (fast)."""
    try:
        with engine.connect() as conn:
            result = conn.execute(text(f"""
                SELECT ISNULL(SUM(p.rows), 0) as row_count
                FROM sys.tables t
                JOIN sys.partitions p ON t.object_id = p.object_id 
                WHERE t.name = '{table_name}' AND p.index_id IN (0, 1)
            """))
            return result.fetchone()[0]
    except Exception:
        return -1


def discover_database(db_name: str) -> Optional[Dict[str, Any]]:
    """Discover schema for a single database."""
    if not test_connection(db_name):
        return None
    
    try:
        engine = build_engine(db_name)
        inspector = inspect(engine)
        
        tables = []
        for table_name in inspector.get_table_names():
            # Skip system tables
            if table_name in ('sysdiagrams', '__EFMigrationsHistory'):
                continue
            
            columns = []
            try:
                for col in inspector.get_columns(table_name):
                    columns.append({
                        "name": col["name"],
                        "type": str(col["type"]),
                        "nullable": col["nullable"],
                    })
            except Exception as e:
                columns = [{"error": str(e)}]
            
            row_count = get_row_count_estimate(engine, table_name)
            
            tables.append({
                "name": table_name,
                "columns": columns,
                "column_count": len(columns),
                "estimated_rows": row_count,
            })
        
        # Sort by row count descending
        tables.sort(key=lambda t: t["estimated_rows"], reverse=True)
        
        total_rows = sum(t["estimated_rows"] for t in tables if t["estimated_rows"] > 0)
        
        return {
            "name": db_name,
            "description": DATABASES.get(db_name, "Unknown"),
            "accessible": True,
            "table_count": len(tables),
            "total_estimated_rows": total_rows,
            "tables": tables,
        }
    except Exception as e:
        return {
            "name": db_name,
            "description": DATABASES.get(db_name, "Unknown"),
            "accessible": False,
            "error": str(e),
        }


def discover_all() -> Dict[str, Any]:
    """Discover schema for all known databases."""
    results = {
        "discovery_timestamp": datetime.now(timezone.utc).isoformat(),
        "server": os.getenv("SQL_SERVER", "unknown"),
        "databases": [],
    }
    
    for db_name in DATABASES.keys():
        print(f"  Checking {db_name}...", end=" ", flush=True)
        db_info = discover_database(db_name)
        if db_info:
            if db_info.get("accessible"):
                print(f"✅ ({db_info['table_count']} tables, ~{db_info['total_estimated_rows']:,} rows)")
            else:
                print(f"❌ (access denied)")
            results["databases"].append(db_info)
        else:
            print("❌ (connection failed)")
            results["databases"].append({
                "name": db_name,
                "description": DATABASES.get(db_name, "Unknown"),
                "accessible": False,
            })
    
    return results


def output_console(data: Dict[str, Any]) -> None:
    """Output results to console in readable format."""
    print("\n" + "=" * 70)
    print("SPACEFLUX CORTEX DATABASE SCHEMA")
    print("=" * 70)
    print(f"Server: {data['server']}")
    print(f"Discovered: {data['discovery_timestamp']}")
    print("=" * 70)
    
    for db in data["databases"]:
        print(f"\n📊 DATABASE: {db['name']}")
        print(f"   Description: {db['description']}")
        
        if not db.get("accessible"):
            print(f"   ❌ Access denied" + (f": {db.get('error', '')}" if db.get('error') else ""))
            continue
        
        print(f"   Tables: {db['table_count']}")
        print(f"   Total Rows: ~{db['total_estimated_rows']:,}")
        print()
        
        for table in db["tables"]:
            rows_str = f"~{table['estimated_rows']:,} rows" if table['estimated_rows'] >= 0 else "unknown rows"
            print(f"   📋 {table['name']} ({table['column_count']} columns, {rows_str})")
            
            for col in table["columns"]:
                if "error" in col:
                    print(f"      ⚠️  Error: {col['error']}")
                else:
                    nullable = "NULL" if col["nullable"] else "NOT NULL"
                    print(f"      • {col['name']:<30} {col['type']:<25} {nullable}")
            print()


def output_json(data: Dict[str, Any]) -> None:
    """Output results as JSON."""
    print(json.dumps(data, indent=2))


def output_markdown(data: Dict[str, Any]) -> None:
    """Output results as Markdown."""
    print("# Spaceflux Cortex Database Schema\n")
    print(f"**Server:** `{data['server']}`  ")
    print(f"**Discovered:** {data['discovery_timestamp']}\n")
    print("---\n")
    
    # Summary table
    print("## Summary\n")
    print("| Database | Description | Tables | Est. Rows | Status |")
    print("|----------|-------------|--------|-----------|--------|")
    for db in data["databases"]:
        if db.get("accessible"):
            status = "✅ Accessible"
            tables = str(db['table_count'])
            rows = f"~{db['total_estimated_rows']:,}"
        else:
            status = "❌ Access Denied"
            tables = "-"
            rows = "-"
        print(f"| {db['name']} | {db['description'][:40]} | {tables} | {rows} | {status} |")
    
    print("\n---\n")
    
    # Detailed schema
    print("## Detailed Schema\n")
    
    for db in data["databases"]:
        print(f"### {db['name']}\n")
        print(f"*{db['description']}*\n")
        
        if not db.get("accessible"):
            print(f"⚠️ **Access denied**\n")
            continue
        
        for table in db["tables"]:
            rows_str = f"~{table['estimated_rows']:,} rows" if table['estimated_rows'] >= 0 else "unknown"
            print(f"#### `{table['name']}` ({rows_str})\n")
            print("| Column | Type | Nullable |")
            print("|--------|------|----------|")
            for col in table["columns"]:
                if "error" not in col:
                    nullable = "Yes" if col["nullable"] else "No"
                    print(f"| {col['name']} | {col['type']} | {nullable} |")
            print()


def main():
    output_format = "console"
    
    if len(sys.argv) > 1:
        if sys.argv[1] in ("--json", "-j"):
            output_format = "json"
        elif sys.argv[1] in ("--markdown", "-m", "--md"):
            output_format = "markdown"
        elif sys.argv[1] in ("--help", "-h"):
            print(__doc__)
            return
    
    print("🔍 Discovering Spaceflux Cortex Database Schema...\n")
    
    try:
        data = discover_all()
    except EnvironmentError as e:
        print(f"\n❌ Configuration Error: {e}")
        print("\nPlease create a .env file with the required variables.")
        print("See the script docstring for details.")
        sys.exit(1)
    
    if output_format == "json":
        output_json(data)
    elif output_format == "markdown":
        output_markdown(data)
    else:
        output_console(data)
    
    print("\n✅ Schema discovery complete!")


if __name__ == "__main__":
    main()
