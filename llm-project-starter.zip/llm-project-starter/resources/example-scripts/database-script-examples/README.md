# Spaceflux Cortex Database Scripts

This folder contains scripts for discovering and exploring the Spaceflux Cortex database system.

## Quick Start

```bash
# Install dependencies (in your project venv or globally)
pip install sqlalchemy pyodbc python-dotenv

# Create .env file with credentials (in project root or this folder)
# See "Environment Variables" below

# Run schema discovery
python discover_schema.py
```

## Script

### `discover_schema.py`

Discovers and documents all database schemas - tables, columns, and row counts.

```bash
python discover_schema.py              # Console output
python discover_schema.py --json       # JSON output
python discover_schema.py --markdown   # Markdown output
```

## Environment Variables

Create a `.env` file with the following variables:

```env
SQL_SERVER=your-server.database.windows.net
SQL_PORT=1433
SQL_READONLY_USERNAME=your_username
SQL_READONLY_PASSWORD=your_password
SQL_DRIVER=FreeTDS
```

**Note:** Use `FreeTDS` for macOS/Linux or `ODBC Driver 17 for SQL Server` for Windows.

## Available Databases

| Database | Description | Est. Rows |
|----------|-------------|-----------|
| `device` | Telescope hardware, observatories, sensors | ~86 |
| `identity` | Users, organizations, roles | ~650 |
| `measurement` | Observation data, tracks | ~38M |
| `catalog` | Space object catalog, TLE data | ~28M |
| `campaign` | Campaign management, missions | ~1.5M |

## Archive

Old/deprecated scripts have been moved to the `archive/` subfolder for reference.

## Dependencies

- Python 3.8+
- sqlalchemy
- pyodbc  
- python-dotenv

**System Requirements:**
- FreeTDS (macOS: `brew install freetds`)
- Or Microsoft ODBC Driver 17 for SQL Server
