# Spaceflux API Script Examples

Example scripts for interacting with the Spaceflux Cortex API.

## Quick Start

```bash
# Install dependencies (in your project venv or globally)
pip install requests python-dotenv

# Create .env file with your API token (in project root or this folder)
echo "BEARER_TOKEN=your_token_here" > .env

# Run scripts
python fetch_telescope_status.py
python fetch_recent_campaigns.py
python fetch_recent_observations.py
```

## Scripts

### `fetch_telescope_status.py`

Fetches all telescope statuses including location, roof status, and weather conditions.

```bash
python fetch_telescope_status.py              # Table output
python fetch_telescope_status.py --json       # JSON output
python fetch_telescope_status.py --no-weather # Skip weather (faster)
```

### `fetch_recent_campaigns.py`

Fetches the most recent campaigns.

```bash
python fetch_recent_campaigns.py              # 50 most recent
python fetch_recent_campaigns.py --limit 20   # Custom limit
python fetch_recent_campaigns.py --json       # JSON output
```

### `fetch_recent_observations.py`

Fetches recently observed objects.

```bash
python fetch_recent_observations.py           # 10 most recent
python fetch_recent_observations.py --limit 20
python fetch_recent_observations.py --json
```

### `create_campaign.py`

Creates a new satellite observation campaign.

```bash
python create_campaign.py --norad 39034 --orbital-regime GEO
python create_campaign.py --norad 25544 --orbital-regime LEO --name "ISS Track"
python create_campaign.py --status CAMPAIGN_ID  # Check status
```

### `fetch_catalog_objects.py`

Fetches satellite catalog records by NORAD ID or searches by name.

```bash
# Fetch by NORAD ID
python fetch_catalog_objects.py --norad 25544           # ISS
python fetch_catalog_objects.py --norad 36516           # SES-1
python fetch_catalog_objects.py --norad 25544 36516     # Multiple satellites

# Search by name (uses Celestrak for lookup)
python fetch_catalog_objects.py --name ISS
python fetch_catalog_objects.py --name "GOES 16"
python fetch_catalog_objects.py --name Starlink --limit 5

# Include TLE data in output
python fetch_catalog_objects.py --norad 25544 --show-tle

# Get full Spaceflux catalog details for name search results
python fetch_catalog_objects.py --name ISS --fetch-details

# JSON output
python fetch_catalog_objects.py --norad 25544 --json
```

### `fetch_org_campaigns.py`

Lists organizations and fetches recent campaigns (tasks) for a specific organization.

```bash
# List all organizations
python fetch_org_campaigns.py --list-orgs

# Fetch campaigns for Spaceflux organization (default)
python fetch_org_campaigns.py

# Fetch campaigns by organization name
python fetch_org_campaigns.py --org-name Spaceflux

# Fetch campaigns by organization ID
python fetch_org_campaigns.py --org-id e1252c18-e019-4ab5-980d-76625ba12990

# Filter by status
python fetch_org_campaigns.py --status active
python fetch_org_campaigns.py --status completed

# Limit results
python fetch_org_campaigns.py --limit 20

# JSON output
python fetch_org_campaigns.py --json
python fetch_org_campaigns.py --list-orgs --json
```

### `fetch_scope_statuses.py`

Alternative telescope status fetcher (used as a module).

```python
from fetch_scope_statuses import get_telescope_status_map
data = get_telescope_status_map()
```

## Environment Variables

Create a `.env` file with:

```env
BEARER_TOKEN=your_api_token_here
```

## API Base URL

All scripts default to `https://api.spaceflux.io`. Override with `--base-url` if needed.

## Dependencies

- Python 3.8+
- requests
- python-dotenv
