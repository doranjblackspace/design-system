#!/usr/bin/env python3
"""
Fetch all telescope statuses (location, roof status, weather) from the Spaceflux API.

Requirements:
    pip install requests python-dotenv

Environment Variables (in .env file):
    BEARER_TOKEN=your_api_token

Usage:
    python fetch_telescope_status.py
    python fetch_telescope_status.py --json
    python fetch_telescope_status.py --no-weather  # Skip weather fetch (faster)
"""

import os
import json
import argparse
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from dotenv import load_dotenv

load_dotenv()

DEFAULT_BASE_URL = "https://api.spaceflux.io"


class APIError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise APIError("Missing BEARER_TOKEN. Set it in .env or environment.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def _fetch_conditions(
    base_url: str,
    telescope_id: str,
    headers: Dict[str, str],
    timeout: int,
) -> Dict[str, Any]:
    """Fetch weather/conditions for a single telescope."""
    url = f"{base_url.rstrip('/')}/v2/telescope/{telescope_id}/conditions"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        if resp.status_code != 200:
            return {}
        
        data = resp.json() if resp.content else {}
        payload = data.get("payload", {}) if isinstance(data, dict) else {}
        weather = payload.get("weather", {}) or {}
        current = weather.get("current", {}) or {}
        latest_metrics = payload.get("latestMetrics", {}) or {}
        
        # Get humidity from metrics
        humidity_metric = latest_metrics.get("telescope.weather.ext_humidity") or {}
        humidity = humidity_metric.get("value", "N/A") if isinstance(humidity_metric, dict) else "N/A"
        
        return {
            "precipitation": current.get("precipitation", "N/A"),
            "humidity": humidity,
            "wind_speed": current.get("windSpeed", "N/A"),
            "cloud_cover": current.get("cloudCover", "N/A"),
            "temperature": current.get("temperature", "N/A"),
            "weather_timestamp": weather.get("time"),
        }
    except Exception:
        return {}


def fetch_telescopes(
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
    include_weather: bool = True,
    max_workers: int = 12,
) -> List[Dict[str, Any]]:
    """
    Fetch all telescopes with their status and optionally weather.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/v2/telescope"
    
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        telescopes_raw = data.get("payload", []) if isinstance(data, dict) else data
        
        if not isinstance(telescopes_raw, list):
            raise APIError("Unexpected response format")
        
        telescopes = []
        ids_to_fetch = {}
        
        for t in telescopes_raw:
            telescope_id = t.get("id")
            name = t.get("name")
            if not telescope_id or not name:
                continue
            
            # Extract status from latestMetrics
            latest = t.get("latestMetrics", {}) or {}
            ops_status = latest.get("telescope.ops.status", {}) or {}
            roof_status = latest.get("telescope.roof.status", {}) or {}
            
            # Get observatory info
            observatory = t.get("observatory", {}) or {}
            
            telescope_info = {
                "id": telescope_id,
                "name": name,
                "latitude": t.get("latitude"),
                "longitude": t.get("longitude"),
                "elevation": t.get("elevation"),
                "observatory": observatory.get("name"),
                "country": observatory.get("country"),
                "timezone": observatory.get("timeZone"),
                "operation_status": ops_status.get("value", "UNKNOWN"),
                "roof_status": roof_status.get("value", "UNKNOWN"),
                "operation_timestamp": ops_status.get("timestamp"),
                "roof_timestamp": roof_status.get("timestamp"),
            }
            
            telescopes.append(telescope_info)
            ids_to_fetch[name] = telescope_id
        
        # Fetch weather concurrently
        if include_weather and ids_to_fetch:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(_fetch_conditions, base_url, tid, headers, timeout): name
                    for name, tid in ids_to_fetch.items()
                }
                for fut in as_completed(futures):
                    name = futures[fut]
                    try:
                        conditions = fut.result()
                        if conditions:
                            # Find and update the telescope entry
                            for t in telescopes:
                                if t["name"] == name:
                                    t.update(conditions)
                                    break
                    except Exception:
                        pass
        
        # Sort by name
        telescopes.sort(key=lambda t: t["name"])
        
        return telescopes
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def main():
    parser = argparse.ArgumentParser(description="Fetch telescope status from Spaceflux API")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--no-weather", action="store_true", help="Skip weather fetch (faster)")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help="API base URL")
    args = parser.parse_args()
    
    print("🔭 Fetching Telescope Status from Spaceflux API\n")
    
    try:
        telescopes = fetch_telescopes(
            base_url=args.base_url,
            include_weather=not args.no_weather
        )
    except APIError as e:
        print(f"❌ Error: {e}")
        return 1
    
    if not telescopes:
        print("No telescopes found.")
        return 0
    
    if args.json:
        print(json.dumps(telescopes, indent=2))
        return 0
    
    # Summary by status
    online = sum(1 for t in telescopes if t.get("operation_status") == "ONLINE")
    offline = sum(1 for t in telescopes if t.get("operation_status") == "OFFLINE")
    roof_open = sum(1 for t in telescopes if t.get("roof_status") == "OPEN")
    
    print(f"📊 Summary: {online} online, {offline} offline, {roof_open} with roof open\n")
    
    # Table output
    print("=" * 130)
    print(f"{'Telescope':<15} {'Observatory':<20} {'Status':<10} {'Roof':<8} {'Temp':<8} {'Humid':<8} {'Cloud':<8} {'Wind':<8}")
    print("-" * 130)
    
    for t in telescopes:
        name = t["name"][:14]
        obs = (t.get("observatory") or "N/A")[:19]
        status = t.get("operation_status", "N/A")[:9]
        roof = t.get("roof_status", "N/A")[:7]
        
        # Weather
        temp = t.get("temperature", "N/A")
        if isinstance(temp, (int, float)):
            temp = f"{temp:.1f}°C"
        else:
            temp = str(temp)[:7]
        
        humid = t.get("humidity", "N/A")
        if isinstance(humid, (int, float)):
            humid = f"{humid:.0f}%"
        else:
            humid = str(humid)[:7]
        
        cloud = t.get("cloud_cover", "N/A")
        if isinstance(cloud, (int, float)):
            cloud = f"{cloud:.0f}%"
        else:
            cloud = str(cloud)[:7]
        
        wind = t.get("wind_speed", "N/A")
        if isinstance(wind, (int, float)):
            wind = f"{wind:.1f}m/s"
        else:
            wind = str(wind)[:7]
        
        # Color indicators (using emoji)
        status_icon = "🟢" if status == "ONLINE" else "🔴" if status == "OFFLINE" else "⚪"
        roof_icon = "🏠" if roof == "OPEN" else "🔒" if roof == "CLOSED" else "❓"
        
        print(f"{status_icon} {name:<13} {obs:<20} {status:<10} {roof_icon}{roof:<6} {temp:<8} {humid:<8} {cloud:<8} {wind:<8}")
    
    print("-" * 130)
    print(f"\n✅ Retrieved status for {len(telescopes)} telescopes")
    return 0


if __name__ == "__main__":
    exit(main())
