#!/usr/bin/env python3
"""
Fetch telescope locations, current state, and weather from Spaceflux API concurrently.

Result (dict keyed by telescope name, e.g. "us-mol-1"):
{
  "<name>": {
    "id": str,
    "name": str,
    "latitude": float | None,
    "longitude": float | None,
    "timezone": str | None,
    "operation_status": str,
    "roof_status": str,
    "operation_timestamp": str | None,
    "roof_timestamp": str | None,
    "precipitation": float | str | None,
    "humidity": float | str | None,
    "wind_speed": float | str | None,
    "cloud_cover": float | str | None,
    "temperature": float | str | None,
    "weather_timestamp": str | None
  },
  ...
}

Usage:
  export BEARER_TOKEN="your_token"
  from telescope_status_client import get_telescope_status_map
  data = get_telescope_status_map()
"""

from __future__ import annotations

import os
import json
from typing import Any, Dict, Optional
import requests
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed


DEFAULT_BASE_URL = "https://api.spaceflux.io"
TELESCOPES_PATH = "/v2/telescope"
CONDITIONS_PATH_TMPL = "/v2/telescope/{telescope_id}/conditions"


class TelescopeStatusError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise TelescopeStatusError("Missing bearer token. Provide token or set BEARER_TOKEN env var.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def _normalize_timezone(timezone_str: str) -> str:
    """Convert timezone strings to standard timezone identifiers"""
    if not timezone_str:
        return None
    
    # Mapping of common timezone names to standard identifiers
    timezone_mapping = {
        "Hawaii Standard Time": "Pacific/Honolulu",
        "Alaska Standard Time": "America/Anchorage",
        "Pacific Standard Time": "America/Los_Angeles",
        "Mountain Standard Time": "America/Denver",
        "Central Standard Time": "America/Chicago",
        "Eastern Standard Time": "America/New_York",
        "Atlantic Standard Time": "America/Halifax",
        "Greenwich Mean Time": "UTC",
        "Coordinated Universal Time": "UTC",
                # European timezone corrections
        "Central European Time": "Europe/Berlin",
        "Central European Summer Time": "Europe/Berlin", 
        "Eastern European Time": "Europe/Athens",
        "Eastern European Summer Time": "Europe/Athens",
        "Western European Time": "Europe/London",
        "Western European Summer Time": "Europe/London",
        # Additional common timezone variations
        "CET": "Europe/Berlin",
        "CEST": "Europe/Berlin", 
        "EET": "Europe/Athens",
        "EEST": "Europe/Athens",
        "WET": "Europe/London",
        "WEST": "Europe/London",
        # Italian timezone (for ita-man-1)
        "Italy Time": "Europe/Rome",
        "Italian Time": "Europe/Rome",
        # Australian timezone corrections
        "Australia/SA": "Australia/Adelaide",
        "Australia/WA": "Australia/Perth",
    }
    
    # Check if it's already a standard timezone identifier
    if "/" in timezone_str and timezone_str not in timezone_mapping:
        return timezone_str
    
    # Use mapping or return as-is if not found
    return timezone_mapping.get(timezone_str, timezone_str)


def _extract_status(telescope: Dict[str, Any]) -> Dict[str, Any]:
    latest = telescope.get("latestMetrics", {}) or {}
    
    # Look for telescope.ops.status in latestMetrics
    ops_status = latest.get("telescope.ops.status", {}) or {}
    roof_status = latest.get("telescope.roof.status", {}) or {}
    
    # Also check top-level fields as fallback
    if not ops_status:
        ops_status = telescope.get("operationStatus", {}) or {}
    if not roof_status:
        roof_status = telescope.get("roofStatus", {}) or {}

    # Extract timezone from observatory object and normalize it
    observatory = telescope.get("observatory", {}) or {}
    raw_timezone = observatory.get("timeZone") or telescope.get("timezone") or telescope.get("timeZone")
    timezone = _normalize_timezone(raw_timezone)

    return {
        "id": telescope.get("id"),
        "name": telescope.get("name"),
        "latitude": telescope.get("latitude"),
        "longitude": telescope.get("longitude"),
        "elevation": telescope.get("elevation"),
        "originator": telescope.get("originator"),
        "timezone": timezone,
        "operation_status": ops_status.get("value", "UNKNOWN"),
        "roof_status": roof_status.get("value", "UNKNOWN"),
        "operation_timestamp": ops_status.get("timestamp"),
        "roof_timestamp": roof_status.get("timestamp"),
    }


def _fetch_conditions(
    base_url: str,
    telescope_id: str,
    headers: Dict[str, str],
    timeout_seconds: int,
) -> Dict[str, Any]:
    url = f"{base_url.rstrip('/')}{CONDITIONS_PATH_TMPL.format(telescope_id=telescope_id)}"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout_seconds)
        if resp.status_code != 200:
            return {}

        data = resp.json() if resp.content else {}
        payload = data.get("payload", {}) if isinstance(data, dict) else {}
        weather = payload.get("weather", {}) or {}
        current = weather.get("current", {}) or {}
        latest_metrics = payload.get("latestMetrics", {}) or {}

        humidity_metric = latest_metrics.get("telescope.weather.ext_humidity") or {}
        humidity = humidity_metric.get("value", "N/A") if isinstance(humidity_metric, dict) else "N/A"

        return {
            "precipitation": current.get("precipitation", "N/A"),
            "humidity": humidity,
            "wind_speed": current.get("windSpeed", "N/A"),
            "cloud_cover": current.get("cloudCover", "N/A"),
            "temperature": current.get("temperature", "N/A"),
            "weather_timestamp": weather.get("time"),
        }
    except requests.exceptions.RequestException:
        return {}


def get_telescope_status_map(
    token: Optional[str] = None,
    base_url: str = DEFAULT_BASE_URL,
    timeout_seconds: int = 30,
    include_weather: bool = True,
    max_workers: int = 12,
) -> Dict[str, Dict[str, Any]]:
    """
    Returns a dict keyed by telescope name with location, current state, and (optionally) weather.
    Weather fetches happen concurrently for speed.
    """
    # Load environment variables from .env once per process
    # Safe to call multiple times; it will be a no-op on subsequent calls
    load_dotenv()
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)

    url = f"{base_url.rstrip('/')}{TELESCOPES_PATH}"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout_seconds)
        if resp.status_code != 200:
            raise TelescopeStatusError(f"API error {resp.status_code}: {resp.text}")

        data = resp.json()
        telescopes = data.get("payload", []) if isinstance(data, dict) else data
        if not isinstance(telescopes, list):
            raise TelescopeStatusError("Unexpected response shape: 'payload' is not a list")

        result: Dict[str, Dict[str, Any]] = {}
        ids_by_name: Dict[str, str] = {}

        # Build base entries
        for t in telescopes:
            name = t.get("name")
            tid = t.get("id")
            if not name or not tid:
                continue
            result[name] = _extract_status(t)
            ids_by_name[name] = tid

        if include_weather and ids_by_name:
            # Fetch conditions concurrently
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(_fetch_conditions, base_url, tid, headers, timeout_seconds): name
                    for name, tid in ids_by_name.items()
                }
                for fut in as_completed(futures):
                    name = futures[fut]
                    try:
                        conditions = fut.result()
                        if conditions:
                            result[name].update(conditions)
                    except Exception:
                        # Leave weather fields absent if this telescope's conditions failed
                        pass

        return result

    except requests.exceptions.RequestException as e:
        raise TelescopeStatusError(f"Request error: {e}") from e


if __name__ == "__main__":
    # CLI: prints JSON to stdout
    try:
        result = get_telescope_status_map()
        print(json.dumps(result, indent=2))
    except TelescopeStatusError as e:
        print(f"Error: {e}", flush=True)
        raise