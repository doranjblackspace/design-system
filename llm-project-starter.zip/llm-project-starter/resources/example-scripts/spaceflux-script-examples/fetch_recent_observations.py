#!/usr/bin/env python3
"""
Fetch the 10 most recently observed objects from the Spaceflux API.

This queries the global scheduler for recent tracks/sessions.

Requirements:
    pip install requests python-dotenv

Environment Variables (in .env file):
    BEARER_TOKEN=your_api_token

Usage:
    python fetch_recent_observations.py
    python fetch_recent_observations.py --limit 20
    python fetch_recent_observations.py --json
"""

import os
import json
import argparse
from typing import Dict, List, Any, Optional
import requests
from dotenv import load_dotenv

load_dotenv()

DEFAULT_BASE_URL = "https://api.spaceflux.io"
SCHEDULER_BASE_URL = "https://scheduler.spaceflux.io"


class APIError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise APIError("Missing BEARER_TOKEN. Set it in .env or environment.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def fetch_catalog_record(
    norad_id: int,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 10,
) -> Optional[Dict[str, Any]]:
    """Fetch satellite info from catalog by NORAD ID."""
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/Catalog/{norad_id}"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, dict) and "payload" in data:
                return data["payload"]
            return data
    except Exception:
        pass
    return None


def fetch_telescope_name(
    telescope_id: str,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 10,
) -> Optional[str]:
    """Fetch telescope name by ID."""
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/v2/telescope/{telescope_id}"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            payload = data.get("payload", data) if isinstance(data, dict) else data
            return payload.get("name")
    except Exception:
        pass
    return None


def fetch_recent_campaigns_with_tracks(
    limit: int = 10,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    Fetch recent campaigns that have observations/tracks.
    
    We fetch campaigns sorted by update time to find ones with recent activity.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    # Get recent campaigns
    url = f"{base_url.rstrip('/')}/Campaign"
    
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        if isinstance(data, dict) and "payload" in data:
            campaigns = data["payload"]
        elif isinstance(data, list):
            campaigns = data
        else:
            campaigns = []
        
        # Sort by updatedAt to get recently active campaigns
        campaigns = sorted(
            campaigns,
            key=lambda c: c.get("updatedAt") or c.get("updated_at") or "",
            reverse=True
        )
        
        # Filter to campaigns that likely have observations
        # (those with status like 'completed', 'active', 'accepted')
        active_statuses = {'completed', 'active', 'accepted', 'running'}
        campaigns = [
            c for c in campaigns 
            if (c.get("status") or "").lower() in active_statuses
        ][:limit * 2]  # Get more than needed, will filter
        
        observations = []
        seen_norads = set()
        
        for campaign in campaigns:
            norad_id = campaign.get("noradId")
            if not norad_id or norad_id in seen_norads:
                continue
            
            seen_norads.add(norad_id)
            
            obs = {
                "campaign_id": campaign.get("id"),
                "norad_id": norad_id,
                "target_name": campaign.get("name") or campaign.get("targetName"),
                "status": campaign.get("status"),
                "orbital_regime": campaign.get("orbitalRegime"),
                "updated_at": campaign.get("updatedAt") or campaign.get("updated_at"),
                "start_time": campaign.get("startTime"),
                "end_time": campaign.get("endTime"),
            }
            
            observations.append(obs)
            
            if len(observations) >= limit:
                break
        
        return observations
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def fetch_scheduler_campaigns(
    limit: int = 10,
    scheduler_url: str = SCHEDULER_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    Fetch campaigns from the global scheduler which has session/track data.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{scheduler_url.rstrip('/')}/api/campaign"
    params = {"limit": limit}
    
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            # Scheduler might not be accessible, fall back
            return []
        
        data = resp.json()
        return data if isinstance(data, list) else []
        
    except Exception:
        return []


def main():
    parser = argparse.ArgumentParser(description="Fetch recent observations from Spaceflux API")
    parser.add_argument("--limit", type=int, default=10, help="Number of observations to fetch (default: 10)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help="API base URL")
    args = parser.parse_args()
    
    print("🛰️  Fetching Recent Observations from Spaceflux API\n")
    
    try:
        # Try scheduler first for most accurate recent data
        scheduler_data = fetch_scheduler_campaigns(limit=args.limit)
        
        if scheduler_data:
            observations = []
            for item in scheduler_data[:args.limit]:
                obs = {
                    "campaign_id": item.get("id") or item.get("campaign_id"),
                    "norad_id": item.get("norad_id") or item.get("noradId"),
                    "target_name": item.get("name") or item.get("target_name"),
                    "status": item.get("status"),
                    "orbital_regime": item.get("orbital_regime") or item.get("orbitalRegime"),
                    "last_session": item.get("last_session_time"),
                }
                observations.append(obs)
        else:
            # Fall back to campaign API
            observations = fetch_recent_campaigns_with_tracks(
                limit=args.limit,
                base_url=args.base_url
            )
            
    except APIError as e:
        print(f"❌ Error: {e}")
        return 1
    
    if not observations:
        print("No recent observations found.")
        return 0
    
    if args.json:
        print(json.dumps(observations, indent=2))
        return 0
    
    # Table output
    print("=" * 110)
    print(f"{'#':<3} {'NORAD':<8} {'Satellite Name':<30} {'Regime':<6} {'Status':<12} {'Last Updated':<20}")
    print("-" * 110)
    
    for i, obs in enumerate(observations, 1):
        norad = str(obs.get("norad_id") or "N/A")
        name = (obs.get("target_name") or "Unknown")[:29]
        regime = (obs.get("orbital_regime") or "N/A")[:5]
        status = (obs.get("status") or "N/A")[:11]
        
        # Parse updated time
        updated_raw = obs.get("updated_at") or obs.get("last_session") or ""
        if updated_raw:
            updated = updated_raw[:16].replace("T", " ")
        else:
            updated = "N/A"
        
        print(f"{i:<3} {norad:<8} {name:<30} {regime:<6} {status:<12} {updated:<20}")
    
    print("-" * 110)
    print(f"\n✅ Retrieved {len(observations)} recent observations")
    
    # Count unique regimes
    regimes = {}
    for obs in observations:
        r = obs.get("orbital_regime") or "Unknown"
        regimes[r] = regimes.get(r, 0) + 1
    
    regime_summary = ", ".join(f"{k}: {v}" for k, v in sorted(regimes.items()))
    print(f"   Orbital regimes: {regime_summary}")
    
    return 0


if __name__ == "__main__":
    exit(main())
