#!/usr/bin/env python3
"""
Fetch the 50 most recent campaigns from the Spaceflux API.

Requirements:
    pip install requests python-dotenv

Environment Variables (in .env file):
    BEARER_TOKEN=your_api_token

Usage:
    python fetch_recent_campaigns.py
    python fetch_recent_campaigns.py --limit 20
    python fetch_recent_campaigns.py --json
"""

import os
import json
import argparse
from typing import Dict, List, Any, Optional
import requests
from dotenv import load_dotenv

load_dotenv()

DEFAULT_BASE_URL = "https://api.spaceflux.io"


class APIError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise APIError("Missing BEARER_TOKEN. Set it in .env or environment.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def fetch_campaigns(
    limit: int = 50,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    Fetch campaigns from the Spaceflux API.
    
    The API returns campaigns sorted by creation date (newest first).
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    # Use the Campaign endpoint
    url = f"{base_url.rstrip('/')}/Campaign"
    
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        # Handle response envelope if present
        if isinstance(data, dict) and "payload" in data:
            campaigns = data["payload"]
        elif isinstance(data, list):
            campaigns = data
        else:
            campaigns = []
        
        # Sort by createdAt descending and limit
        campaigns = sorted(
            campaigns,
            key=lambda c: c.get("createdAt") or c.get("created_at") or "",
            reverse=True
        )[:limit]
        
        return campaigns
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def main():
    parser = argparse.ArgumentParser(description="Fetch recent campaigns from Spaceflux API")
    parser.add_argument("--limit", type=int, default=50, help="Number of campaigns to fetch (default: 50)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help="API base URL")
    args = parser.parse_args()
    
    print("🚀 Fetching Recent Campaigns from Spaceflux API\n")
    
    try:
        campaigns = fetch_campaigns(limit=args.limit, base_url=args.base_url)
    except APIError as e:
        print(f"❌ Error: {e}")
        return 1
    
    if not campaigns:
        print("No campaigns found.")
        return 0
    
    if args.json:
        print(json.dumps(campaigns, indent=2))
        return 0
    
    # Table output
    print("=" * 110)
    print(f"{'#':<3} {'Name':<30} {'NORAD':<8} {'Status':<12} {'Regime':<6} {'Created':<20}")
    print("-" * 110)
    
    for i, c in enumerate(campaigns, 1):
        name = (c.get("name") or c.get("targetName") or "N/A")[:29]
        norad = str(c.get("noradId") or "N/A")
        status = (c.get("status") or "N/A")[:11]
        regime = (c.get("orbitalRegime") or "N/A")[:5]
        
        # Parse created date
        created_raw = c.get("createdAt") or c.get("created_at") or ""
        if created_raw:
            # Handle ISO format
            created = created_raw[:16].replace("T", " ")
        else:
            created = "N/A"
        
        print(f"{i:<3} {name:<30} {norad:<8} {status:<12} {regime:<6} {created:<20}")
    
    print("-" * 110)
    print(f"\n✅ Retrieved {len(campaigns)} campaigns")
    return 0


if __name__ == "__main__":
    exit(main())
