#!/usr/bin/env python3
"""
Fetch satellite catalog records from the Spaceflux API.

Demonstrates:
  - Fetching a catalog record by NORAD ID
  - Searching for satellites by name (via Celestrak)
  - Querying multiple records at once
  - Displaying orbital parameters and TLE data

Requirements:
    pip install requests python-dotenv

Environment Variables (in .env file):
    BEARER_TOKEN=your_api_token

Usage:
    # Fetch by NORAD ID
    python fetch_catalog_objects.py --norad 25544          # ISS
    python fetch_catalog_objects.py --norad 36516          # SES-1

    # Search by name (uses Celestrak for name lookup)
    python fetch_catalog_objects.py --name ISS
    python fetch_catalog_objects.py --name "GOES 16"
    python fetch_catalog_objects.py --name Starlink --limit 5

    # Query multiple NORAD IDs
    python fetch_catalog_objects.py --norad 25544 36516 20580

    # Output options
    python fetch_catalog_objects.py --norad 25544 --json
    python fetch_catalog_objects.py --norad 25544 --show-tle
"""

import os
import json
import argparse
from typing import Dict, List, Any, Optional
import requests
from dotenv import load_dotenv

load_dotenv()

DEFAULT_BASE_URL = "https://api.spaceflux.io"
CELESTRAK_URL = "https://celestrak.org/NORAD/elements/gp.php"


class APIError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise APIError("Missing BEARER_TOKEN. Set it in .env or environment.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def fetch_catalog_record(
    norad_id: int,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 15,
) -> Optional[Dict[str, Any]]:
    """
    Fetch a single catalog record by NORAD ID.
    
    Endpoint: GET /cat/record/{id}
    
    Returns the catalog record with orbital parameters, TLE, and metadata.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/cat/record/{norad_id}"
    
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        # Handle response envelope
        if isinstance(data, dict) and "payload" in data:
            return data["payload"]
        return data
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def query_catalog_records(
    norad_ids: List[int],
    cat_type: str = "spaceflux",
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    Query multiple catalog records by NORAD IDs.
    
    Endpoint: POST /cat/record/query
    
    Args:
        norad_ids: List of NORAD IDs to query
        cat_type: Catalog type - "spaceflux" or "norad"
    
    Returns a list of catalog records.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    headers["Content-Type"] = "application/json"
    
    url = f"{base_url.rstrip('/')}/cat/record/query"
    payload = {
        "iDs": norad_ids,
        "catType": cat_type,
    }
    
    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        if isinstance(data, dict) and "payload" in data:
            return data["payload"] or []
        elif isinstance(data, list):
            return data
        return []
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def search_satellites_by_name(
    name: str,
    limit: int = 10,
    timeout: int = 15,
) -> List[Dict[str, Any]]:
    """
    Search for satellites by name using Celestrak GP data.
    
    This performs a case-insensitive search against Celestrak's catalog
    and returns matching satellites with their NORAD IDs.
    
    Note: This does not require authentication as it uses public Celestrak data.
    """
    # Celestrak provides JSON format GP data
    params = {
        "GROUP": "active",  # Search active satellites
        "FORMAT": "json",
    }
    
    try:
        resp = requests.get(CELESTRAK_URL, params=params, timeout=timeout)
        
        if resp.status_code != 200:
            # Try alternative - search specific name
            params = {
                "NAME": name,
                "FORMAT": "json",
            }
            resp = requests.get(CELESTRAK_URL, params=params, timeout=timeout)
        
        if resp.status_code != 200:
            return []
        
        data = resp.json()
        
        if not isinstance(data, list):
            return []
        
        # Filter by name (case-insensitive)
        name_lower = name.lower()
        matches = []
        
        for sat in data:
            sat_name = sat.get("OBJECT_NAME", "")
            if name_lower in sat_name.lower():
                matches.append({
                    "norad_id": sat.get("NORAD_CAT_ID"),
                    "name": sat_name,
                    "object_id": sat.get("OBJECT_ID"),
                    "epoch": sat.get("EPOCH"),
                    "inclination": sat.get("INCLINATION"),
                    "period": sat.get("PERIOD"),
                    "apoapsis": sat.get("APOAPSIS"),
                    "periapsis": sat.get("PERIAPSIS"),
                })
        
        # Sort by relevance (exact match first, then alphabetically)
        matches.sort(key=lambda x: (
            0 if x["name"].lower() == name_lower else 1,
            x["name"]
        ))
        
        return matches[:limit]
        
    except requests.exceptions.RequestException:
        return []
    except json.JSONDecodeError:
        return []


def format_orbital_regime(regime: Optional[str]) -> str:
    """Format orbital regime with description."""
    descriptions = {
        "LEO": "LEO (Low Earth Orbit)",
        "MEO": "MEO (Medium Earth Orbit)",
        "GEO": "GEO (Geostationary)",
        "GTO": "GTO (Geostationary Transfer)",
        "HEO": "HEO (Highly Elliptical)",
        "DECAYED": "DECAYED",
    }
    return descriptions.get(regime, regime or "Unknown")


def format_rcs(rcs: Optional[str]) -> str:
    """Format radar cross section."""
    if not rcs:
        return "N/A"
    return f"{rcs}"


def print_catalog_record(record: Dict[str, Any], show_tle: bool = False) -> None:
    """Print a catalog record in a readable format."""
    print()
    print("=" * 70)
    print(f"  {record.get('satName') or record.get('objectName') or 'Unknown'}")
    print("=" * 70)
    
    print(f"  NORAD ID:        {record.get('noradId') or record.get('id', 'N/A')}")
    print(f"  Object ID:       {record.get('objectID', 'N/A')}")
    print(f"  Type:            {record.get('type', 'N/A')}")
    print(f"  Country:         {record.get('country', 'N/A')}")
    
    print()
    print("  Orbital Parameters:")
    print(f"    Regime:        {format_orbital_regime(record.get('orbitalRegime'))}")
    
    period = record.get('period')
    if period:
        print(f"    Period:        {period:.2f} min")
    
    inclination = record.get('inclination')
    if inclination is not None:
        print(f"    Inclination:   {inclination:.2f}°")
    
    apogee = record.get('apogee')
    if apogee is not None:
        print(f"    Apogee:        {apogee:.1f} km")
    
    perigee = record.get('perigee')
    if perigee is not None:
        print(f"    Perigee:       {perigee:.1f} km")
    
    rcs = record.get('rcs')
    if rcs:
        print(f"    RCS:           {format_rcs(rcs)}")
    
    print()
    print("  Launch Information:")
    print(f"    Launch Date:   {record.get('launchDate', 'N/A')}")
    print(f"    Launch Year:   {record.get('launchYear', 'N/A')}")
    
    decay = record.get('decay')
    if decay:
        print(f"    Decay Date:    {decay}")
    
    print()
    print("  Data Timestamps:")
    tle_epoch = record.get('tleEpoch', '')
    if tle_epoch:
        print(f"    TLE Epoch:     {tle_epoch[:19].replace('T', ' ')}")
    
    updated = record.get('updatedAt', '')
    if updated:
        print(f"    Last Updated:  {updated[:19].replace('T', ' ')}")
    
    if show_tle and record.get('tle'):
        print()
        print("  Two-Line Element Set (TLE):")
        print("  " + "-" * 68)
        for line in record['tle'].strip().split('\n'):
            print(f"    {line}")
        print("  " + "-" * 68)
    
    print()


def print_search_results(results: List[Dict[str, Any]]) -> None:
    """Print satellite search results in a table format."""
    if not results:
        print("No matching satellites found.")
        return
    
    print()
    print("=" * 90)
    print(f"{'#':<3} {'NORAD':<8} {'Name':<35} {'Inc':<8} {'Period':<10} {'Apogee':<10}")
    print("-" * 90)
    
    for i, sat in enumerate(results, 1):
        norad = str(sat.get('norad_id', 'N/A'))
        name = (sat.get('name', 'Unknown'))[:34]
        
        inc = sat.get('inclination')
        inc_str = f"{inc:.1f}°" if inc is not None else "N/A"
        
        period = sat.get('period')
        period_str = f"{period:.1f} min" if period else "N/A"
        
        apogee = sat.get('apoapsis')
        apogee_str = f"{apogee:.0f} km" if apogee else "N/A"
        
        print(f"{i:<3} {norad:<8} {name:<35} {inc_str:<8} {period_str:<10} {apogee_str:<10}")
    
    print("-" * 90)
    print(f"\n✅ Found {len(results)} matching satellite(s)")


def main():
    parser = argparse.ArgumentParser(
        description="Fetch satellite catalog records from the Spaceflux API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --norad 25544                    # Fetch ISS by NORAD ID
  %(prog)s --norad 25544 36516              # Fetch multiple satellites
  %(prog)s --name "GOES 16"                 # Search by name
  %(prog)s --name Starlink --limit 5        # Search with limit
  %(prog)s --norad 25544 --show-tle         # Include TLE data
  %(prog)s --norad 25544 --json             # JSON output
        """
    )
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--norad",
        type=int,
        nargs="+",
        metavar="ID",
        help="NORAD catalog ID(s) to fetch",
    )
    group.add_argument(
        "--name",
        type=str,
        metavar="NAME",
        help="Search for satellites by name (case-insensitive)",
    )
    
    parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Maximum number of search results (default: 10)",
    )
    parser.add_argument(
        "--show-tle",
        action="store_true",
        help="Display TLE data for each satellite",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    parser.add_argument(
        "--base-url",
        default=DEFAULT_BASE_URL,
        help="API base URL",
    )
    parser.add_argument(
        "--fetch-details",
        action="store_true",
        help="When searching by name, also fetch full catalog details from Spaceflux API",
    )
    
    args = parser.parse_args()
    
    # Search by name
    if args.name:
        print(f"🔍 Searching for satellites matching: {args.name}\n")
        
        results = search_satellites_by_name(args.name, limit=args.limit)
        
        if not results:
            print("❌ No satellites found matching that name.")
            print("   Try a different search term or check spelling.")
            return 1
        
        if args.json:
            print(json.dumps(results, indent=2))
            return 0
        
        # If user wants full details, fetch from Spaceflux API
        if args.fetch_details and results:
            print("📡 Fetching full catalog details from Spaceflux API...\n")
            
            norad_ids = [r['norad_id'] for r in results if r.get('norad_id')]
            
            try:
                records = query_catalog_records(norad_ids, base_url=args.base_url)
                
                if args.json:
                    print(json.dumps(records, indent=2))
                    return 0
                
                for record in records:
                    print_catalog_record(record, show_tle=args.show_tle)
                
                return 0
                
            except APIError as e:
                print(f"⚠️  Could not fetch full details: {e}")
                print("   Showing Celestrak search results instead.\n")
        
        print_search_results(results)
        
        if not args.fetch_details:
            print("\n💡 Tip: Use --fetch-details to get full catalog data from Spaceflux API")
        
        return 0
    
    # Fetch by NORAD ID(s)
    norad_ids = args.norad
    
    print(f"🛰️  Fetching catalog record(s) for NORAD ID(s): {', '.join(map(str, norad_ids))}\n")
    
    try:
        if len(norad_ids) == 1:
            # Single record - use direct endpoint
            record = fetch_catalog_record(norad_ids[0], base_url=args.base_url)
            
            if not record:
                print(f"❌ No catalog record found for NORAD ID {norad_ids[0]}")
                return 1
            
            if args.json:
                print(json.dumps(record, indent=2))
                return 0
            
            print_catalog_record(record, show_tle=args.show_tle)
            
        else:
            # Multiple records - use query endpoint
            records = query_catalog_records(norad_ids, base_url=args.base_url)
            
            if not records:
                print("❌ No catalog records found for the specified NORAD IDs")
                return 1
            
            if args.json:
                print(json.dumps(records, indent=2))
                return 0
            
            for record in records:
                print_catalog_record(record, show_tle=args.show_tle)
            
            print(f"✅ Retrieved {len(records)} catalog record(s)")
        
        return 0
        
    except APIError as e:
        print(f"❌ Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
