import os
import time
import json
from typing import Any, Dict, Optional
from datetime import datetime, timedelta, timezone
import requests
from dotenv import load_dotenv
import argparse
import base64


class SpacefluxAPIError(RuntimeError):
    """Raised when the Spaceflux API returns a non-success response."""


def _iso(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _auth_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "WeatherDash/1.0",
    }


def _load_token() -> str:
    load_dotenv()
    token = os.getenv("BEARER_TOKEN")
    if not token:
        raise SpacefluxAPIError("Missing BEARER_TOKEN in environment or .env")
    return token


def create_campaign(
    norad_id: int,
    name: Optional[str] = None,
    starts_at: Optional[datetime] = None,
    ends_at: Optional[datetime] = None,
    priority: Optional[int] = None,  # kept for CLI compatibility; not sent to API
    notes: Optional[str] = None,      # kept for CLI compatibility; not sent to API
    *,
    base_url: str = "https://api.spaceflux.io",
    timeout: int = 30,
    extra: Optional[Dict[str, Any]] = None,
    organization_id: Optional[str] = None,
    orbital_regime: str = "GEO",
    target_mode: str = "noradid",
) -> Dict[str, Any]:
    """
    Create a campaign with defaults:
      start: now (UTC)
      end: start + 1h
      name: Spaceflux Campaign {YYYY-MM-DD HH:MMZ}

    Token read from .env as BEARER_TOKEN.
    """
    token = _load_token()
    
    # Verify JWT token format and expiration
    try:
        parts = token.split(".")
        if len(parts) >= 2:
            b64 = parts[1]
            pad = "=" * (-len(b64) % 4)
            payload_claims = json.loads(base64.urlsafe_b64decode(b64 + pad).decode("utf-8"))
            
            # Check token expiration
            exp_timestamp = payload_claims.get("exp")
            if exp_timestamp:
                import time
                current_time = int(time.time())
                if current_time > exp_timestamp:
                    print(f"DEBUG: WARNING - JWT token is expired!")
                    print(f"DEBUG: Current time: {current_time}, Token expires: {exp_timestamp}")
                else:
                    print(f"DEBUG: JWT token is valid, expires in {exp_timestamp - current_time} seconds")
            
            # Check token issuer and audience
            iss = payload_claims.get("iss")
            aud = payload_claims.get("aud")
            print(f"DEBUG: Token issuer: {iss}")
            print(f"DEBUG: Token audience: {aud}")
            
    except Exception as e:
        print(f"DEBUG: Error parsing JWT token: {e}")
    
    # Use the known working endpoint
    url = f"{base_url.rstrip('/')}/Campaign"
    print(f"DEBUG: Using endpoint: {url}")
    print(f"DEBUG: Token length: {len(token) if token else 0}")

    if starts_at is None:
        starts_at = datetime.now(timezone.utc)
    if ends_at is None:
        ends_at = starts_at + timedelta(hours=1)
    if not name:
        ts = starts_at.strftime("%Y-%m-%d %H:%MZ")
        name = f"Spaceflux Campaign {ts}"

    # Resolve organization ID: explicit arg > ORG_ID env > JWT claim (sf_orgs)
    org_id = organization_id or os.getenv("ORG_ID")
    if not org_id:
        try:
            parts = _load_token().split(".")
            if len(parts) >= 2:
                b64 = parts[1]
                pad = "=" * (-len(b64) % 4)
                payload_claims = json.loads(base64.urlsafe_b64decode(b64 + pad).decode("utf-8"))
                sf_orgs = payload_claims.get("sf_orgs")
                if isinstance(sf_orgs, str):
                    org_id = sf_orgs.split(":")[0]
                elif isinstance(sf_orgs, list) and sf_orgs:
                    first = sf_orgs[0]
                    if isinstance(first, str):
                        org_id = first.split(":")[0]
                # fallback if organizationID claim exists
                if not org_id and isinstance(payload_claims.get("organizationID"), str):
                    org_id = payload_claims["organizationID"]
        except Exception:
            pass
    if not org_id:
        raise SpacefluxAPIError("Missing organization ID. Provide --organization-id, set ORG_ID env, or use a token with sf_orgs claim.")

    payload: Dict[str, Any] = {
        "name": name,
        "organizationID": org_id,
        "targetMode": target_mode,      # "noradid" or "tle"
        "noradId": int(norad_id),
        "orbitalRegime": orbital_regime,  # e.g., "GEO"
        "startEndDates": [
            {"start": _iso(starts_at), "end": _iso(ends_at)}
        ],
    }
    # Merge allowed/known extras (e.g., networkIds, shareWith, deliverAllInFoV, isDataExclusive, etc.)
    if extra:
        for k, v in extra.items():
            payload[k] = v

    # Add debugging for troubleshooting
    print(f"DEBUG: Making POST request to: {url}")
    print(f"DEBUG: Headers: {dict(_auth_headers(token))}")
    print(f"DEBUG: Payload: {json.dumps(payload, indent=2)}")
    
    # Make the POST request directly to the known working endpoint
    resp = requests.post(url, headers=_auth_headers(token), data=json.dumps(payload), timeout=timeout)
    
    print(f"DEBUG: POST response status: {resp.status_code}")
    print(f"DEBUG: POST response headers: {dict(resp.headers)}")
    print(f"DEBUG: POST response body: {resp.text[:1000]}...")
    
    if not resp.ok:
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text
    
    print(f"DEBUG: Response status: {resp.status_code}")
    print(f"DEBUG: Response headers: {dict(resp.headers)}")
    print(f"DEBUG: Response body: {resp.text[:1000]}...")

    # Retry logic is now handled in the URL testing loop above

    if not resp.ok:
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text
        
        # For 401 errors, try to get more details
        if resp.status_code == 401:
            print(f"DEBUG: 401 Unauthorized - checking response details")
            print(f"DEBUG: Response headers: {dict(resp.headers)}")
            print(f"DEBUG: Response body: {resp.text}")
            
            # Check if there are any authentication-related headers
            auth_headers = {k: v for k, v in resp.headers.items() if 'auth' in k.lower() or 'www-authenticate' in k.lower()}
            if auth_headers:
                print(f"DEBUG: Authentication headers: {auth_headers}")
        
        raise SpacefluxAPIError(f"Create campaign failed: {resp.status_code} {detail}")

    return resp.json()


def create_default_campaign(
    norad_id: int,
    *,
    base_url: str = "https://api.spaceflux.io",
    timeout: int = 30,
    notes: Optional[str] = None,
    priority: Optional[int] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Minimal helper: only NORAD ID is required.
    """
    return create_campaign(
        norad_id=norad_id,
        name=None,
        starts_at=None,
        ends_at=None,
        priority=priority,
        notes=notes,
        base_url=base_url,
        timeout=timeout,
        extra=extra,
    )


def get_campaign(
    campaign_id: str,
    *,
    base_url: str = "https://api.spaceflux.io",
    timeout: int = 20,
) -> Dict[str, Any]:
    """
    Fetch a campaign resource by ID.
    """
    token = _load_token()
    url = f"{base_url.rstrip('/')}/Campaign/{campaign_id}"
    resp = requests.get(url, headers=_auth_headers(token), timeout=timeout)

    if resp.status_code in (429, 502, 503, 504):
        time.sleep(0.5)
        resp = requests.get(url, headers=_auth_headers(token), timeout=timeout)

    if not resp.ok:
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text
        raise SpacefluxAPIError(f"Get campaign failed: {resp.status_code} {detail}")

    return resp.json()


def get_campaign_status(
    campaign_id: str,
    *,
    base_url: str = "https://api.spaceflux.io",
    timeout: int = 20,
) -> Dict[str, Any]:
    """
    Return a small status view:
      {id, name, state, starts_at, ends_at, progress, last_update}
    Fields mapped defensively in case the API evolves.
    """
    data = get_campaign(campaign_id, base_url=base_url, timeout=timeout)

    # Defensive extraction
    state = data.get("state") or data.get("status") or data.get("lifecycle_state")
    progress = (
        data.get("progress")
        or data.get("percent_complete")
        or data.get("completion")
    )
    last_update = (
        data.get("updated_at")
        or data.get("last_updated")
        or data.get("modified_at")
    )

    return {
        "id": data.get("id"),
        "name": data.get("name"),
        "state": state,
        "starts_at": data.get("starts_at"),
        "ends_at": data.get("ends_at"),
        "progress": progress,
        "last_update": last_update,
        "raw": data,  # keep original for debugging if needed
    }


def main() -> int:
    """
    Simple CLI for creating a campaign or fetching status.

    Examples:
      Create for Skynet 5D (NORAD 39034):
        python scripts/create_campaign.py --norad 39034 --notes "Test Skynet 5D" --priority 3

      Fetch status:
        python scripts/create_campaign.py --status CAMPAIGN_ID
    """
    import sys

    parser = argparse.ArgumentParser(description="Create or query Spaceflux campaigns.")
    parser.add_argument("--norad", type=int, help="Target NORAD ID (e.g., 39034 for Skynet 5D)")
    parser.add_argument("--name", type=str, help="Optional campaign name")
    parser.add_argument("--priority", type=int, help="Optional priority integer (ignored by API)")
    parser.add_argument("--notes", type=str, help="Optional notes (ignored by API)")
    parser.add_argument(
        "--extra",
        type=str,
        help="Optional JSON string to merge into payload (e.g., '{\"networkIds\":[\"uuid-1\"],\"deliverAllInFoV\":true}')",
    )
    parser.add_argument(
        "--organization-id",
        dest="organization_id",
        type=str,
        help="Organization UUID. If omitted, uses ORG_ID env or JWT sf_orgs",
    )
    parser.add_argument(
        "--orbital-regime",
        dest="orbital_regime",
        type=str,
        default="GEO",
        choices=["UNKNOWN", "LEO", "MEO", "GEO", "GTO", "HEO"],
        help="Orbital regime for the campaign (default: GEO)",
    )
    parser.add_argument(
        "--target-mode",
        dest="target_mode",
        type=str,
        default="noradid",
        choices=["noradid", "tle"],
        help="Target mode (default: noradid)",
    )
    parser.add_argument(
        "--base-url",
        dest="base_url",
        default="https://api.spaceflux.io",
        help="API base URL (service root hosting /Campaign endpoints)",
    )
    parser.add_argument("--timeout", type=int, default=30, help="Request timeout in seconds")
    parser.add_argument(
        "--status",
        type=str,
        help="Fetch status for a campaign ID and exit (skips creation)",
    )

    args = parser.parse_args()

    if args.status:
        out = get_campaign_status(args.status, base_url=args.base_url, timeout=20)
        print(json.dumps(out, indent=2))
        return 0

    if args.norad is None:
        parser.error("--norad is required unless --status is provided")

    extra_obj = None
    if args.extra:
        try:
            extra_obj = json.loads(args.extra)
        except Exception as e:
            print(f"Invalid --extra JSON: {e}", file=sys.stderr)
            return 2

    created = create_campaign(
        norad_id=args.norad,
        name=args.name,
        starts_at=None,
        ends_at=None,
        priority=args.priority,
        notes=args.notes,
        base_url=args.base_url,
        timeout=args.timeout,
        extra=extra_obj,
        organization_id=args.organization_id,
        orbital_regime=args.orbital_regime,
        target_mode=args.target_mode,
    )
    print(json.dumps(created, indent=2))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())