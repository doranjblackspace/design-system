#!/usr/bin/env python3
"""
Fetch organizations and their recent campaigns (tasks) from the Spaceflux API.

Demonstrates:
  - Listing all organizations
  - Fetching recent campaigns for a specific organization
  - Using the Spaceflux organization as an example

Requirements:
    pip install requests python-dotenv

Environment Variables (in .env file):
    BEARER_TOKEN=your_api_token

Usage:
    # List all organizations
    python fetch_org_campaigns.py --list-orgs

    # List campaigns for Spaceflux organization (default)
    python fetch_org_campaigns.py

    # List campaigns for a specific organization by ID
    python fetch_org_campaigns.py --org-id e1252c18-e019-4ab5-980d-76625ba12990

    # List campaigns for an organization by name
    python fetch_org_campaigns.py --org-name Spaceflux

    # Limit number of campaigns
    python fetch_org_campaigns.py --limit 20

    # Output as JSON
    python fetch_org_campaigns.py --json
"""

import os
import json
import argparse
from typing import Dict, List, Any, Optional
import requests
from dotenv import load_dotenv

load_dotenv()

DEFAULT_BASE_URL = "https://api.spaceflux.io"

# Spaceflux organization ID (used as default example)
SPACEFLUX_ORG_ID = "e1252c18-e019-4ab5-980d-76625ba12990"


class APIError(Exception):
    pass


def _auth_headers(token: str) -> Dict[str, str]:
    if not token:
        raise APIError("Missing BEARER_TOKEN. Set it in .env or environment.")
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def list_organizations(
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    List all organizations.
    
    Endpoint: GET /organization
    
    Returns a list of organizations with their details.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/organization"
    
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code == 403:
            raise APIError("Access denied. You may not have permission to list organizations.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        # Handle response envelope
        if isinstance(data, dict) and "payload" in data:
            return data["payload"] or []
        elif isinstance(data, list):
            return data
        return []
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def get_organization_by_name(
    name: str,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Find an organization by name (case-insensitive match).
    """
    orgs = list_organizations(base_url=base_url, token=token)
    name_lower = name.lower()
    
    for org in orgs:
        org_name = org.get("name", "")
        if org_name and org_name.lower() == name_lower:
            return org
    
    # Try partial match if exact match not found
    for org in orgs:
        org_name = org.get("name", "")
        if org_name and name_lower in org_name.lower():
            return org
    
    return None


def fetch_campaigns(
    organization_id: Optional[str] = None,
    limit: int = 50,
    status: Optional[str] = None,
    base_url: str = DEFAULT_BASE_URL,
    token: Optional[str] = None,
    timeout: int = 30,
) -> List[Dict[str, Any]]:
    """
    Fetch campaigns, optionally filtered by organization.
    
    Endpoint: GET /Campaign
    
    Args:
        organization_id: Filter campaigns by organization ID
        limit: Maximum number of campaigns to return
        status: Filter by status (e.g., "anyof(active)", "anyof(completed)")
    
    Returns a list of campaigns.
    """
    token = token or os.getenv("BEARER_TOKEN")
    headers = _auth_headers(token)
    
    url = f"{base_url.rstrip('/')}/Campaign"
    params = {
        "limit": limit,
        "sort": "-createdAt",  # Sort by creation date, newest first
    }
    
    if status:
        params["status"] = status
    
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=timeout)
        
        if resp.status_code == 401:
            raise APIError("Authentication failed. Check your BEARER_TOKEN.")
        if resp.status_code != 200:
            raise APIError(f"API error {resp.status_code}: {resp.text[:200]}")
        
        data = resp.json()
        
        # Handle response envelope
        if isinstance(data, dict) and "payload" in data:
            campaigns = data["payload"] or []
        elif isinstance(data, list):
            campaigns = data
        else:
            campaigns = []
        
        # Filter by organization ID if specified
        if organization_id:
            campaigns = [
                c for c in campaigns 
                if c.get("organizationId") == organization_id
                or c.get("organizationID") == organization_id
            ]
        
        return campaigns[:limit]
        
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {e}")


def print_organizations(orgs: List[Dict[str, Any]]) -> None:
    """Print organizations in a table format."""
    if not orgs:
        print("No organizations found.")
        return
    
    print()
    print("=" * 100)
    print(f"{'#':<3} {'Name':<30} {'ID':<40} {'Users':<8} {'Active':<8}")
    print("-" * 100)
    
    for i, org in enumerate(orgs, 1):
        name = (org.get("name") or "N/A")[:29]
        org_id = org.get("id", "N/A")
        user_count = org.get("userCount")
        user_str = str(user_count) if user_count is not None else "N/A"
        is_active = org.get("isActive")
        active_str = "Yes" if is_active else ("No" if is_active is False else "N/A")
        
        print(f"{i:<3} {name:<30} {org_id:<40} {user_str:<8} {active_str:<8}")
    
    print("-" * 100)
    print(f"\n✅ Found {len(orgs)} organization(s)")


def print_campaigns(campaigns: List[Dict[str, Any]], org_name: Optional[str] = None) -> None:
    """Print campaigns in a table format."""
    if not campaigns:
        print("No campaigns found for this organization.")
        return
    
    print()
    if org_name:
        print(f"  Campaigns for: {org_name}")
    print("=" * 120)
    print(f"{'#':<3} {'Name':<35} {'NORAD':<8} {'Status':<12} {'Regime':<6} {'Created':<20}")
    print("-" * 120)
    
    for i, c in enumerate(campaigns, 1):
        name = (c.get("name") or c.get("targetName") or "N/A")[:34]
        norad = str(c.get("noradId") or "N/A")
        status = (c.get("status") or "N/A")[:11]
        regime = (c.get("orbitalRegime") or "N/A")[:5]
        
        # Parse created date
        created_raw = c.get("createdAt") or c.get("created_at") or ""
        if created_raw:
            created = created_raw[:16].replace("T", " ")
        else:
            created = "N/A"
        
        print(f"{i:<3} {name:<35} {norad:<8} {status:<12} {regime:<6} {created:<20}")
    
    print("-" * 120)
    print(f"\n✅ Found {len(campaigns)} campaign(s)")
    
    # Summary statistics
    statuses = {}
    regimes = {}
    for c in campaigns:
        s = c.get("status") or "Unknown"
        statuses[s] = statuses.get(s, 0) + 1
        r = c.get("orbitalRegime") or "Unknown"
        regimes[r] = regimes.get(r, 0) + 1
    
    if statuses:
        status_summary = ", ".join(f"{k}: {v}" for k, v in sorted(statuses.items()))
        print(f"   By status: {status_summary}")
    
    if regimes:
        regime_summary = ", ".join(f"{k}: {v}" for k, v in sorted(regimes.items()))
        print(f"   By regime: {regime_summary}")


def main():
    parser = argparse.ArgumentParser(
        description="Fetch organizations and their campaigns from the Spaceflux API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --list-orgs                          # List all organizations
  %(prog)s                                      # Campaigns for Spaceflux org (default)
  %(prog)s --org-name Spaceflux                 # Campaigns by org name
  %(prog)s --org-id e1252c18-e019-4ab5-980d-76625ba12990
  %(prog)s --limit 20                           # Limit results
  %(prog)s --status active                      # Filter by status
  %(prog)s --json                               # JSON output
        """
    )
    
    parser.add_argument(
        "--list-orgs",
        action="store_true",
        help="List all organizations and exit",
    )
    parser.add_argument(
        "--org-id",
        type=str,
        metavar="UUID",
        help=f"Organization ID to fetch campaigns for (default: Spaceflux {SPACEFLUX_ORG_ID})",
    )
    parser.add_argument(
        "--org-name",
        type=str,
        metavar="NAME",
        help="Organization name to search for",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Maximum number of campaigns to fetch (default: 50)",
    )
    parser.add_argument(
        "--status",
        type=str,
        choices=["active", "completed", "cancelled", "pending", "accepted"],
        help="Filter campaigns by status",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    parser.add_argument(
        "--base-url",
        default=DEFAULT_BASE_URL,
        help="API base URL",
    )
    
    args = parser.parse_args()
    
    try:
        # List organizations mode
        if args.list_orgs:
            print("🏢 Fetching Organizations from Spaceflux API\n")
            
            orgs = list_organizations(base_url=args.base_url)
            
            if args.json:
                print(json.dumps(orgs, indent=2))
                return 0
            
            print_organizations(orgs)
            return 0
        
        # Determine which organization to use
        org_id = args.org_id
        org_name = None
        
        if args.org_name:
            print(f"🔍 Looking up organization: {args.org_name}\n")
            org = get_organization_by_name(args.org_name, base_url=args.base_url)
            
            if not org:
                print(f"❌ Organization '{args.org_name}' not found.")
                print("   Use --list-orgs to see available organizations.")
                return 1
            
            org_id = org.get("id")
            org_name = org.get("name")
            print(f"   Found: {org_name} (ID: {org_id})")
        
        # Default to Spaceflux organization
        if not org_id:
            org_id = SPACEFLUX_ORG_ID
            org_name = "Spaceflux"
            print(f"📡 Using default organization: {org_name}")
        
        # Build status filter
        status_filter = None
        if args.status:
            status_filter = f"anyof({args.status})"
        
        print(f"🚀 Fetching Campaigns for Organization\n")
        
        campaigns = fetch_campaigns(
            organization_id=org_id,
            limit=args.limit,
            status=status_filter,
            base_url=args.base_url,
        )
        
        if args.json:
            output = {
                "organization": {
                    "id": org_id,
                    "name": org_name,
                },
                "campaigns": campaigns,
                "count": len(campaigns),
            }
            print(json.dumps(output, indent=2))
            return 0
        
        print_campaigns(campaigns, org_name=org_name)
        
        return 0
        
    except APIError as e:
        print(f"❌ Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
