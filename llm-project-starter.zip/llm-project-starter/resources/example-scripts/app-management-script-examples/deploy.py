import os
import paramiko
import boto3
import subprocess
import webbrowser
import getpass
import argparse
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ---------------------
# Configuration
# ---------------------
APP_NAME = os.getenv("APP_NAME", "geo")  # Unique identifier for this app
AWS_INSTANCE_ID = os.getenv("AWS_INSTANCE_ID", "i-xxxxxxxxxxxxxxx")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
AWS_PROFILE = os.getenv("AWS_PROFILE", "sf-account")  # Default to sf-account profile
SSH_KEY_PATH = os.path.expanduser(os.getenv("SSH_KEY_PATH", "~/your-key.pem"))
LOCAL_APP_FOLDER = os.path.dirname(os.path.abspath(__file__))  # Current directory
REMOTE_APP_FOLDER = f"/home/{os.getenv('EC2_USERNAME', 'ubuntu')}/{APP_NAME}"
HTTP_SERVER_PORT = int(os.getenv("HTTP_SERVER_PORT", "9021"))  # Port for this app
EC2_USERNAME = os.getenv("EC2_USERNAME", "ubuntu")

# Authentication credentials
AUTH_USERNAME = os.getenv("AUTH_USERNAME", "spaceflux")
AUTH_PASSWORD = os.getenv("AUTH_PASSWORD", "TheIvories2025!")

# For Nginx config (Amazon Linux uses conf.d instead of sites-available)
LOCAL_NGINX_CONFIG = os.path.join(LOCAL_APP_FOLDER, "nginx", f"{APP_NAME}app")
REMOTE_NGINX_CONFIG = f"/etc/nginx/conf.d/{APP_NAME}app.conf"
REMOTE_HTPASSWD_PATH = f"/etc/nginx/.htpasswd-{APP_NAME}"

# Define authorized IPs that don't need password - load from environment
AUTHORIZED_IPS_ENV = os.getenv("AUTHORIZED_IPS", "127.0.0.1")
AUTHORIZED_IPS = [ip.strip() for ip in AUTHORIZED_IPS_ENV.split(",")]
ssh_passphrase = None  # cache to reuse for multiple SSH connections

# ---------------------
# Helper Functions
# ---------------------
def get_ssh_key():
    """Get SSH key, handling both encrypted and unencrypted keys."""
    global ssh_passphrase
    
    # Try all key types in order (RSA is most common, so try it first)
    key_classes = [paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, paramiko.DSSKey]
    
    if ssh_passphrase is None:
        # First pass: try without passphrase
        needs_passphrase = False
        for key_class in key_classes:
            try:
                return key_class.from_private_key_file(SSH_KEY_PATH, password=None)
            except Exception as e:
                # Check if it's an encryption-related error (covers multiple exception types)
                error_str = str(e).lower()
                if "encrypted" in error_str or "passphrase" in error_str or "password" in error_str:
                    needs_passphrase = True
                # Continue trying other key types
                continue
        
        # If we get here and need a passphrase, ask for it and try again
        if needs_passphrase:
            ssh_passphrase = getpass.getpass(prompt="Enter SSH key passphrase: ")
            for key_class in key_classes:
                try:
                    return key_class.from_private_key_file(SSH_KEY_PATH, password=ssh_passphrase)
                except Exception:
                    # Wrong key type or wrong passphrase, try next one
                    continue
            raise Exception(f"Could not load SSH key with provided passphrase - check passphrase is correct")
        else:
            raise Exception(f"Could not load SSH key - file may be corrupted or in unsupported format")
    else:
        # Passphrase already cached, try all key types
        for key_class in key_classes:
            try:
                return key_class.from_private_key_file(SSH_KEY_PATH, password=ssh_passphrase)
            except Exception:
                continue
        raise Exception(f"Could not load SSH key with cached passphrase")
def get_instance_address(instance_id):
    """Fetch the public DNS or IP of the EC2 instance."""
    if AWS_PROFILE:
        session = boto3.Session(profile_name=AWS_PROFILE)
        ec2 = session.client('ec2', region_name=AWS_REGION)
    else:
        ec2 = boto3.client('ec2', region_name=AWS_REGION)
    response = ec2.describe_instances(InstanceIds=[instance_id])
    reservations = response.get('Reservations', [])
    if reservations:
        instance = reservations[0]['Instances'][0]
        return instance.get('PublicDnsName') or instance.get('PublicIpAddress')
    raise Exception("Instance not found or no public address available.")

def get_instance_elastic_ip(instance_id):
    """Fetch the instance's public IP."""
    if AWS_PROFILE:
        session = boto3.Session(profile_name=AWS_PROFILE)
        ec2 = session.client('ec2', region_name=AWS_REGION)
    else:
        ec2 = boto3.client('ec2', region_name=AWS_REGION)
    response = ec2.describe_instances(InstanceIds=[instance_id])
    reservations = response.get('Reservations', [])
    if reservations:
        instance = reservations[0]['Instances'][0]
        elastic_ip = instance.get('PublicIpAddress')
        if elastic_ip:
            return elastic_ip
    raise Exception("Instance not found or no public IP available.")

AWS_INSTANCE_IP = get_instance_address(AWS_INSTANCE_ID)
AWS_INSTANCE_DOMAIN = os.getenv("DOMAIN_NAME", "geo.spaceflux.xyz")

def sync_files(upload_db=False):
    """Sync local app files (e.g., HTML, images) to the EC2 instance."""
    print("Syncing files with EC2 instance...")
    
    # First, ensure the remote directory exists and has proper permissions
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # Use ssh-agent (key is already loaded there)
    ssh.connect(AWS_INSTANCE_IP, username=EC2_USERNAME)
    
    # Create directory and set initial permissions
    prep_commands = [
        f"mkdir -p {REMOTE_APP_FOLDER}",
        f"sudo chmod 755 /home/{EC2_USERNAME}/",  # Allow Nginx to traverse
        f"sudo chown -R {EC2_USERNAME}:{EC2_USERNAME} {REMOTE_APP_FOLDER}"  # Ensure ec2-user owns files for rsync
    ]
    
    for cmd in prep_commands:
        print(f"Preparing directory: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            err = stderr.read().decode().strip()
            print(f"Warning: {cmd} failed: {err}")
    
    ssh.close()
    
    # Build rsync exclusions
    exclusions = ["venv/", ".venv/"]  # Always exclude virtual environments
    
    if not upload_db:
        # Exclude database files when not uploading database
        exclusions.extend([
            "*.db",
            "*.sqlite",
            "*.sqlite3",
            "scans.db",
            "record/",
            "scan_metadata/"
        ])
        print("⚠️  Database files excluded from sync (use --upload-db to include)")
    
    # Build rsync command with exclusions
    # Use ssh-agent if key is loaded there, otherwise specify key file
    exclude_args = " ".join([f"--exclude '{exc}'" for exc in exclusions])
    
    # Check if key is in ssh-agent
    ssh_agent_check = subprocess.run("ssh-add -l", shell=True, capture_output=True, text=True)
    
    if ssh_agent_check.returncode == 0 and "spaceflux-xyz-key" in ssh_agent_check.stdout:
        # Key is in ssh-agent, use it without -i flag
        print("✓ Using SSH key from ssh-agent")
        rsync_command = (
            f"rsync -avz {exclude_args} "
            f"-e 'ssh -o StrictHostKeyChecking=no' "
            f"{LOCAL_APP_FOLDER}/ {EC2_USERNAME}@{AWS_INSTANCE_IP}:{REMOTE_APP_FOLDER}/"
        )
    else:
        # Fall back to specifying key file directly
        print("✓ Using SSH key file directly")
        rsync_command = (
            f"rsync -avz {exclude_args} "
            f"-e 'ssh -i {SSH_KEY_PATH} -o StrictHostKeyChecking=no' "
            f"{LOCAL_APP_FOLDER}/ {EC2_USERNAME}@{AWS_INSTANCE_IP}:{REMOTE_APP_FOLDER}/"
        )
    
    subprocess.run(rsync_command, shell=True, check=True)

def upload_database_files():
    """Upload database files specifically to the EC2 instance."""
    print("📁 Uploading database files to EC2 instance...")
    
    # Database files to upload
    db_files = [
        "scans.db",
        "record/",
        "scan_metadata/"
    ]
    
    # Check which files exist locally
    existing_files = []
    for file_pattern in db_files:
        if os.path.exists(os.path.join(LOCAL_APP_FOLDER, file_pattern)):
            existing_files.append(file_pattern)
        else:
            print(f"⚠️  Database file/directory not found locally: {file_pattern}")
    
    if not existing_files:
        print("❌ No database files found to upload")
        return
    
    print(f"📤 Uploading database files: {', '.join(existing_files)}")
    
    # Check if key is in ssh-agent
    ssh_agent_check = subprocess.run("ssh-add -l", shell=True, capture_output=True, text=True)
    use_ssh_agent = ssh_agent_check.returncode == 0 and "spaceflux-xyz-key" in ssh_agent_check.stdout
    
    if use_ssh_agent:
        print("✓ Using SSH key from ssh-agent")
    else:
        print("✓ Using SSH key file directly")
    
    # Upload each database file/directory
    for db_file in existing_files:
        local_path = os.path.join(LOCAL_APP_FOLDER, db_file)
        remote_path = f"{REMOTE_APP_FOLDER}/{db_file}"
        
        if os.path.isfile(local_path):
            # Single file upload
            if use_ssh_agent:
                rsync_command = (
                    f"rsync -avz "
                    f"-e 'ssh -o StrictHostKeyChecking=no' "
                    f"{local_path} {EC2_USERNAME}@{AWS_INSTANCE_IP}:{remote_path}"
                )
            else:
                rsync_command = (
                    f"rsync -avz "
                    f"-e 'ssh -i {SSH_KEY_PATH} -o StrictHostKeyChecking=no' "
                    f"{local_path} {EC2_USERNAME}@{AWS_INSTANCE_IP}:{remote_path}"
                )
        else:
            # Directory upload
            if use_ssh_agent:
                rsync_command = (
                    f"rsync -avz "
                    f"-e 'ssh -o StrictHostKeyChecking=no' "
                    f"{local_path}/ {EC2_USERNAME}@{AWS_INSTANCE_IP}:{remote_path}/"
                )
            else:
                rsync_command = (
                    f"rsync -avz "
                    f"-e 'ssh -i {SSH_KEY_PATH} -o StrictHostKeyChecking=no' "
                    f"{local_path}/ {EC2_USERNAME}@{AWS_INSTANCE_IP}:{remote_path}/"
                )
        
        print(f"Uploading {db_file}...")
        subprocess.run(rsync_command, shell=True, check=True)
    
    print("✅ Database files uploaded successfully")

def migrate_remote_database():
    """Run database schema migrations on remote database."""
    print("🔄 Running database migrations on remote server...")
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    ssh.connect(AWS_INSTANCE_IP, username=EC2_USERNAME)
    
    # Run the automation tracking migration script
    automation_migration_cmd = f"cd {REMOTE_APP_FOLDER} && python3 add_automation_tracking.py"
    print(f"Running automation tracking migration: {automation_migration_cmd}")
    stdin, stdout, stderr = ssh.exec_command(automation_migration_cmd)
    exit_status = stdout.channel.recv_exit_status()
    
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    
    if out:
        print(out)
    
    if exit_status != 0:
        print(f"⚠️  Automation migration exit code: {exit_status}")
        if err:
            print(f"Automation migration error output:\n{err}")
        ssh.close()
        raise Exception("Automation tracking migration failed")
    
    # Run any other migration scripts if they exist
    other_migration_cmd = f"cd {REMOTE_APP_FOLDER} && python3 migrate_schema.py scans.db"
    print(f"Running other migrations: {other_migration_cmd}")
    stdin, stdout, stderr = ssh.exec_command(other_migration_cmd)
    exit_status = stdout.channel.recv_exit_status()
    
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    
    if out:
        print(out)
    
    if exit_status != 0:
        print(f"⚠️  Other migration exit code: {exit_status}")
        if err:
            print(f"Other migration error output:\n{err}")
        # Don't fail deployment if other migrations don't exist
        print("ℹ️  Other migrations not found or failed - continuing deployment")
    
    ssh.close()
    print("✅ Database migrations completed successfully")

def setup_remote_env_and_performance():
    """Setup .env file and performance optimizations on remote EC2 instance."""
    print("Setting up .env file and performance optimizations on EC2 instance...")
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    ssh.connect(AWS_INSTANCE_IP, username=EC2_USERNAME)
    
    # First, copy the local .env file to remote
    print("Copying .env file to EC2...")
    sftp = ssh.open_sftp()
    local_env_path = os.path.join(LOCAL_APP_FOLDER, '.env')
    remote_env_path = f"{REMOTE_APP_FOLDER}/.env"
    
    try:
        sftp.put(local_env_path, remote_env_path)
        print(f"✓ Copied .env file to {remote_env_path}")
    except FileNotFoundError:
        print("WARNING: Local .env file not found, skipping .env setup")
        sftp.close()
        ssh.close()
        return
    
    sftp.close()
    
    # CRITICAL: Ensure DEV_MODE is set to false for production
    # This is FOOLPROOF - removes any existing DEV_MODE lines and adds DEV_MODE=false
    print("="*80)
    print("🚨 CRITICAL: FORCING PRODUCTION MODE (DEV_MODE=false)")
    print("="*80)
    
    # Multi-step approach to be absolutely certain:
    # 1. Remove ALL existing DEV_MODE lines (commented or not)
    # 2. Remove ALLOW_DEV_CAMPAIGNS lines
    # 3. Add fresh DEV_MODE=false at the end
    # 4. Verify multiple times
    
    dev_mode_fix_script = f"""
cd {REMOTE_APP_FOLDER}

echo "📋 BEFORE modification:"
grep -i dev_mode .env || echo "  (no DEV_MODE found)"

echo ""
echo "🔧 Removing any existing DEV_MODE and ALLOW_DEV_CAMPAIGNS lines..."
# Remove all lines containing DEV_MODE (case insensitive)
sed -i '/DEV_MODE/Id' .env
# Remove all lines containing ALLOW_DEV_CAMPAIGNS
sed -i '/ALLOW_DEV_CAMPAIGNS/Id' .env

echo ""
echo "✅ Adding DEV_MODE=false to production .env..."
echo "DEV_MODE=false" >> .env

echo ""
echo "📋 AFTER modification:"
grep -i dev_mode .env || echo "  ERROR: DEV_MODE not found!"

echo ""
echo "🔍 Full .env file (last 10 lines):"
tail -10 .env

echo ""
if grep -q "^DEV_MODE=false" .env; then
    echo "✅✅✅ SUCCESS: DEV_MODE=false is SET"
else
    echo "❌❌❌ FAILURE: DEV_MODE=false is NOT SET!"
    exit 1
fi
"""
    
    print("Executing production mode enforcement script...")
    stdin, stdout, stderr = ssh.exec_command(dev_mode_fix_script)
    exit_status = stdout.channel.recv_exit_status()
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    
    print(out)
    if err:
        print(f"Stderr: {err}")
    
    if exit_status != 0:
        ssh.close()
        raise Exception("❌ CRITICAL FAILURE: Could not set DEV_MODE=false in production!")
    
    print("="*80)
    print("✅ PRODUCTION MODE LOCKED IN - DEV_MODE=false")
    print("✅ Campaign creation ENABLED via Cortex API")
    print("="*80)
    
    # Verify SQL driver configuration and FreeTDS availability
    print("🔧 Verifying SQL driver configuration and FreeTDS availability...")
    freetds_commands = [
        f"cd {REMOTE_APP_FOLDER}",
        # Verify the current setting
        "echo 'Current SQL_DRIVER:' && grep SQL_DRIVER .env || echo 'SQL_DRIVER not found in .env'",
        # Check if FreeTDS is available
        "echo 'Checking FreeTDS availability:' && python3 -c 'import pyodbc; drivers = pyodbc.drivers(); print(\"Available drivers:\", drivers); print(\"FreeTDS available:\", \"FreeTDS\" in drivers)'",
        # Test tsql command
        "echo 'Testing tsql command:' && which tsql && echo 'tsql found' || echo 'tsql not found'"
    ]
    
    for cmd in freetds_commands:
        print(f"Running: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print(f"  Output: {out}")
        if err and exit_status != 0:
            print(f"  Error: {err}")
    
    # Fix 2: Turn off DEBUG logging for performance
    print("🚀 Optimizing performance (disable DEBUG logging)...")
    logging_commands = [
        f"cd {REMOTE_APP_FOLDER}",
        # Create backup of app.py
        "cp app.py app.py.backup_$(date +%Y%m%d_%H%M%S)",
        # Change DEBUG to WARNING logging
        r'''python3 -c "
import re
with open('app.py', 'r') as f:
    content = f.read()
content = re.sub(r'logging\.basicConfig\(level=logging\.DEBUG\)', 'logging.basicConfig(level=logging.WARNING)', content)
with open('app.py', 'w') as f:
    f.write(content)
print('✓ Changed logging level from DEBUG to WARNING')
"''',
        # Verify the logging change
        "echo 'Logging level after fix:' && grep 'basicConfig.*level' app.py"
    ]
    
    for cmd in logging_commands:
        print(f"Running: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print(f"  Output: {out}")
        if err and exit_status != 0:
            print(f"  Error: {err}")
    
    # Test satellite data connection (optional database test)
    print("🧪 Testing satellite data connection...")
    test_satellite_cmd = f"""cd {REMOTE_APP_FOLDER} && python3 -c "
import os
from dotenv import load_dotenv
load_dotenv()
print('Testing satellite data sources...')
try:
    # Test Space-Track.org credentials
    spacetrack_user = os.getenv('SPACETRACK_USER')
    spacetrack_pass = os.getenv('SPACETRACK_PASS')
    if spacetrack_user and spacetrack_pass:
        print('✅ Space-Track.org credentials configured')
    else:
        print('⚠️  Space-Track.org credentials not found in .env')
    
    # Test weather API keys
    meteosource_key = os.getenv('METEOSOURCE_API_KEY')
    openweather_key = os.getenv('OPENWEATHERMAP_API_KEY')
    if meteosource_key and openweather_key:
        print('✅ Weather API keys configured')
    else:
        print('⚠️  Weather API keys not found in .env')
        
    print('✅ Satellite data configuration check completed')
except Exception as e:
    print(f'❌ Configuration check failed: {{e}}')
"
"""
    
    stdin, stdout, stderr = ssh.exec_command(test_satellite_cmd)
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    
    if out:
        print(f"Configuration test result:\n{out}")
    if err:
        print(f"Configuration test error: {err}")
    
    # Restart Flask service to apply all changes
    print("🔄 Restarting Flask service to apply changes...")
    restart_cmd = f"sudo systemctl restart {APP_NAME}-flask.service"
    stdin, stdout, stderr = ssh.exec_command(restart_cmd)
    exit_status = stdout.channel.recv_exit_status()
    
    if exit_status == 0:
        print("✅ Flask service restarted successfully")
    else:
        print(f"⚠️  Flask restart exit code: {exit_status}")
    
    ssh.close()
    print("✅ Remote environment and performance optimizations completed!")

def setup_nginx():
    """
    Create and upload an Nginx config file to proxy from port 80 to the Flask application on the specified port,
    and then reload Nginx.
    """
    print("Setting up Nginx on EC2 instance...")

    nginx_config_content = f"""server {{
    listen 80;
    server_name {AWS_INSTANCE_DOMAIN};

    # Serve static files directly (no authentication required) - MUST BE FIRST
    location /static/ {{
        alias {REMOTE_APP_FOLDER}/static/;
        expires 30d;
        
        # Allow all access to static files
        allow all;
        
        # Add CORS headers for static files
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range' always;
    }}

    # Satellite data READ-ONLY endpoints - NO AUTHENTICATION REQUIRED
    location ~ ^/(geo_satellites|dashboard_data|satellite_orbit) {{
        # Allow all access to read-only satellite data endpoints
        allow all;
        
        # Handle OPTIONS for CORS
        if ($request_method = 'OPTIONS') {{
            add_header 'Access-Control-Allow-Origin' '*';
            add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE';
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization';
            add_header 'Access-Control-Max-Age' 1728000;
            add_header 'Content-Type' 'text/plain; charset=utf-8';
            add_header 'Content-Length' 0;
            return 204;
        }}
        
        # Proxy to Flask application
        proxy_pass http://127.0.0.1:{HTTP_SERVER_PORT};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Add CORS headers
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization' always;
        add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;
    }}

    # Main application - WITH AUTHENTICATION
    location / {{
        # Allow specific IPs without authentication
        satisfy any;
        allow 82.32.68.14;
        allow 80.177.36.21;
        deny all;
        
        # Basic authentication
        auth_basic "Restricted Access";
        auth_basic_user_file {REMOTE_HTPASSWD_PATH};
        
        # Handle OPTIONS for CORS
        if ($request_method = 'OPTIONS') {{
            add_header 'Access-Control-Allow-Origin' '*';
            add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE';
            add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization';
            add_header 'Access-Control-Max-Age' 1728000;
            add_header 'Content-Type' 'text/plain; charset=utf-8';
            add_header 'Content-Length' 0;
            return 204;
        }}
        
        # Proxy to Flask application
        proxy_pass http://127.0.0.1:{HTTP_SERVER_PORT};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Add CORS headers
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE' always;
        add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization' always;
        add_header 'Access-Control-Expose-Headers' 'Content-Length,Content-Range' always;
    }}
}}
"""

    final_remote_config = REMOTE_NGINX_CONFIG
    temp_remote_config = "/tmp/geodashapp.conf"

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ssh.connect(AWS_INSTANCE_IP, username=EC2_USERNAME)

    # Install nginx if not already installed (Amazon Linux)
    print("Installing nginx...")
    install_commands = [
        "sudo yum update -y",
        "sudo yum install -y nginx",
        "sudo yum install -y certbot python3-certbot-nginx",
        "sudo systemctl enable nginx",
        "sudo systemctl start nginx"
    ]
    
    for cmd in install_commands:
        print(f"Running: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print("STDOUT:", out)
        if err and "already installed" not in err.lower():
            print("STDERR:", err)

    print("Creating .htpasswd file with credentials...")
    htpasswd_cmd = f"printf \"{AUTH_USERNAME}:$(openssl passwd -apr1 '{AUTH_PASSWORD}')\\n\" | sudo tee " + REMOTE_HTPASSWD_PATH
    stdin, stdout, stderr = ssh.exec_command(htpasswd_cmd)
    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        err = stderr.read().decode().strip()
        ssh.close()
        raise Exception(f"Failed to create .htpasswd file: {err}")
    ssh.exec_command(f"sudo chmod 644 {REMOTE_HTPASSWD_PATH}")
    # Remove default nginx config for Amazon Linux
    ssh.exec_command("sudo rm -f /etc/nginx/conf.d/default.conf")
    
    sftp = ssh.open_sftp()
    with sftp.open(temp_remote_config, "w") as remote_file:
        remote_file.write(nginx_config_content)
    sftp.close()

    commands = [
        f"sudo mv {temp_remote_config} {final_remote_config}",
        "sudo nginx -t",
        "sudo systemctl reload nginx"
    ]

    for cmd in commands:
        print(f"Running command: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print("STDOUT:", out)
        if err:
            print("STDERR:", err)
        if exit_status != 0:
            ssh.close()
            raise Exception(f"Nginx config command '{cmd}' failed with exit code {exit_status}")

    admin_email = os.getenv("ADMIN_EMAIL", "admin@example.com")
    certbot_command = f"sudo certbot --nginx -d {AWS_INSTANCE_DOMAIN} --non-interactive --agree-tos -m {admin_email} --redirect"
    print("Running Certbot to obtain SSL certificate...")
    stdin, stdout, stderr = ssh.exec_command(certbot_command)
    print(stdout.read().decode())
    print(stderr.read().decode())

    # Check nginx error logs for any issues
    print("Checking nginx error logs for any issues...")
    log_check_cmd = "sudo tail -n 20 /var/log/nginx/error.log"
    stdin, stdout, stderr = ssh.exec_command(log_check_cmd)
    nginx_logs = stdout.read().decode().strip()
    if nginx_logs:
        print("Recent nginx error logs:")
        print(nginx_logs)
    else:
        print("No recent nginx errors found.")
    
    ssh.close()
    print("Nginx setup completed with HTTP Basic Authentication.")

def setup_systemd_service():
    """
    Creates/updates a systemd service file to run the Flask application
    automatically starts and restarts on reboot.
    """
    print(f"Creating/updating systemd service for {APP_NAME} Flask application...")

    service_name = f"{APP_NAME}-flask"
    service_file = f"/etc/systemd/system/{service_name}.service"

    service_content = f"""[Unit]
Description=GEO Surveillance Dashboard Flask Application
After=network.target

[Service]
User={EC2_USERNAME}
WorkingDirectory={REMOTE_APP_FOLDER}
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
Environment="FLASK_APP=app.py"
Environment="FLASK_ENV=production"
# Create virtual environment if it doesn't exist
ExecStartPre=/bin/bash -c 'if [ ! -d {REMOTE_APP_FOLDER}/venv ]; then python3 -m venv {REMOTE_APP_FOLDER}/venv; fi'
# Install requirements
ExecStartPre={REMOTE_APP_FOLDER}/venv/bin/pip install -r {REMOTE_APP_FOLDER}/requirements.txt
# Install gunicorn explicitly
ExecStartPre={REMOTE_APP_FOLDER}/venv/bin/pip install gunicorn
# Run Flask application with gunicorn
ExecStart={REMOTE_APP_FOLDER}/venv/bin/gunicorn --workers 3 --timeout 120 --bind 0.0.0.0:{HTTP_SERVER_PORT} --access-logfile - --error-logfile - app:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
"""

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ssh.connect(AWS_INSTANCE_IP, username=EC2_USERNAME)

    # First, stop the old static file server service if it exists
    print(f"Stopping old {APP_NAME} static file server service if it exists...")
    stop_old_service_cmd = f"sudo systemctl stop {APP_NAME}-static.service || true"
    stdin, stdout, stderr = ssh.exec_command(stop_old_service_cmd)
    stdout.channel.recv_exit_status()
    
    # Create venv directory with proper permissions
    print("Setting up Python environment...")
    prep_commands = [
        f"mkdir -p {REMOTE_APP_FOLDER}",
        f"sudo yum update -y",
        f"sudo yum install -y python3 python3-pip python3-venv",
        f"python3 -m venv {REMOTE_APP_FOLDER}/venv || true",
        f"{REMOTE_APP_FOLDER}/venv/bin/pip install --upgrade pip",
        f"{REMOTE_APP_FOLDER}/venv/bin/pip install gunicorn flask"
    ]
    
    for cmd in prep_commands:
        print(f"Running command: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print("STDOUT:", out)
        if err:
            print("STDERR:", err)
    
    # Verify app.py exists
    print("Verifying app.py exists...")
    check_app_cmd = f"ls -la {REMOTE_APP_FOLDER}/app.py"
    stdin, stdout, stderr = ssh.exec_command(check_app_cmd)
    exit_status = stdout.channel.recv_exit_status()
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()
    if exit_status != 0:
        print(f"WARNING: app.py not found! Deployment might fail. Error: {err}")
    else:
        print(f"app.py found: {out}")
    
    # Set proper permissions on static files and directories
    print("Setting proper permissions on static files and directories...")
    perm_commands = [
        f"sudo chmod 755 /home/{EC2_USERNAME}/",  # Allow Nginx to traverse home directory
        f"sudo chown -R nginx:nginx {REMOTE_APP_FOLDER}/static",  # Nginx owns static files
        f"sudo chmod -R 755 {REMOTE_APP_FOLDER}/static",  # Proper directory permissions
        f"sudo find {REMOTE_APP_FOLDER}/static -type f -exec chmod 644 {{}} \\;"  # Proper file permissions
    ]
    
    for cmd in perm_commands:
        print(f"Running permission command: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print("STDOUT:", out)
        if err:
            print("STDERR:", err)

    temp_remote_path = f"/tmp/{service_name}.service"
    sftp = ssh.open_sftp()
    with sftp.file(temp_remote_path, "w") as f:
        f.write(service_content)
    sftp.close()

    commands = [
        f"sudo systemctl stop {service_name}.service || true",
        f"sudo systemctl disable {service_name}.service || true",
        f"sudo rm -f {service_file}",
        f"sudo mv {temp_remote_path} {service_file}",
        f"sudo chmod 644 {service_file}",
        "sudo systemctl daemon-reload",
        f"sudo systemctl enable {service_name}.service",
        f"sudo systemctl restart {service_name}.service"
    ]

    for cmd in commands:
        print(f"Running command: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode().strip()
        err = stderr.read().decode().strip()
        if out:
            print("STDOUT:", out)
        if err:
            print("STDERR:", err)
        if exit_status != 0:
            print(f"Command '{cmd}' failed with exit code {exit_status}")
            # Instead of raising exception immediately, get service status for debugging
            if "restart" in cmd:
                print("Checking service status for error details...")
                status_cmd = f"sudo systemctl status {service_name}.service"
                stdin, stdout, stderr = ssh.exec_command(status_cmd)
                print(stdout.read().decode())
                print(stderr.read().decode())
                
                log_cmd = f"sudo journalctl -xeu {service_name}.service --no-pager -n 50"
                stdin, stdout, stderr = ssh.exec_command(log_cmd)
                print(stdout.read().decode())
                
                ssh.close()
                raise Exception(f"Service failed to start. See logs above for details.")
            else:
                ssh.close()
                raise Exception(f"Command '{cmd}' failed with exit code {exit_status}")

    # Verify the service is actually running
    print("Verifying service status...")
    status_cmd = f"sudo systemctl status {service_name}.service"
    stdin, stdout, stderr = ssh.exec_command(status_cmd)
    status_output = stdout.read().decode()
    print(status_output)
    
    if "active (running)" not in status_output:
        print("WARNING: Service may not be running correctly. Check logs for errors.")
    
    # Test HTTP connectivity to the service
    print("Testing HTTP connectivity to the Flask service...")
    curl_cmd = f"curl -sS http://localhost:{HTTP_SERVER_PORT}/"
    stdin, stdout, stderr = ssh.exec_command(curl_cmd)
    curl_output = stdout.read().decode()
    curl_error = stderr.read().decode()
    
    if curl_error:
        print(f"WARNING: Could not connect to Flask service: {curl_error}")
    else:
        print(f"Successfully connected to Flask service. Response starts with: {curl_output[:100]}...")
    
    ssh.close()
    print(f"Systemd service created and started. Flask application is running on port {HTTP_SERVER_PORT}.")

def open_browser():
    """Open the GEO Surveillance Dashboard in a browser."""
    url = f"https://{AWS_INSTANCE_DOMAIN}"
    print(f"Opening GEO Surveillance Dashboard in browser: {url}")
    webbrowser.open(url)

# ---------------------
# Main Deploy Flow
# ---------------------
if __name__ == "__main__":
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Deploy GEO Surveillance Dashboard to EC2')
    parser.add_argument('--upload-db', action='store_true', 
                       help='Upload database files (scans.db, record/, scan_metadata/) to production')
    args = parser.parse_args()
    
    try:
        # 1. Sync local code (HTML and other assets)
        sync_files(upload_db=args.upload_db)
        
        # 2. Upload database files if requested OR run migrations
        if args.upload_db:
            upload_database_files()
            print("📝 Database files uploaded - migrations will ensure schema is current")
        
        # 3. Run database schema migrations (safe for existing data)
        migrate_remote_database()
        
        # 4. Setup .env file with correct SQL driver for Linux + performance optimizations
        setup_remote_env_and_performance()
        
        # 5. Configure/Reload Nginx (port 80 -> proxy to Flask app on port 9021)
        setup_nginx()
        
        # 6. Create or update systemd service for the Flask application
        setup_systemd_service()
        
        # 7. Clean up any old services that might interfere with our Flask app
        print(f"Performing final cleanup of any conflicting {APP_NAME} services...")
        cleanup_cmd = f"ssh -i {SSH_KEY_PATH} {EC2_USERNAME}@{AWS_INSTANCE_IP} 'sudo systemctl stop {APP_NAME}-static.service || true && sudo systemctl disable {APP_NAME}-static.service || true && ps aux | grep \"[p]ython -m http.server\" | awk {{\"print $2\"}} | xargs -r kill -9'"
        subprocess.run(cleanup_cmd, shell=True, check=False)
        
        # 8. Open the app in your browser
        open_browser()
        print("Deployment successful!")
        
        if args.upload_db:
            print("⚠️  Database files were uploaded to production!")
        else:
            print("ℹ️  Database files were NOT uploaded (use --upload-db to include them)")
        
        print("\nIMPORTANT: If the GEO Surveillance Dashboard doesn't load properly, try:")
        print("1. Check if the Flask application started properly")
        print("2. Ensure app.py contains routes for '/', '/geo', and '/instant'")
        print(f"3. Try manually restarting the service: ssh {EC2_USERNAME}@{AWS_INSTANCE_DOMAIN} 'sudo systemctl restart {APP_NAME}-flask.service'")
        print(f"4. Check logs: ssh {EC2_USERNAME}@{AWS_INSTANCE_DOMAIN} 'sudo journalctl -u {APP_NAME}-flask.service'")
        print(f"5. Test satellite data: curl https://{AWS_INSTANCE_DOMAIN}/geo_satellites")
        
    except Exception as e:
        print(f"Deployment failed: {e}")